/**
 * Created on 16.11.2004
 */
package spinfo.ql.variations;

import java.util.Vector;

/**
 * @author Fabian Steeg
 */
public class RecursiveVariationsGeneratorFromNet
		implements
			IVariationsGenerator {
	private String a;
	private int n;
	private Vector v;
	public RecursiveVariationsGeneratorFromNet(String a, int n) {
		this.a = a;
		this.n = n;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see spinfo.ql.variations.IVariationsGenerator#getVariations()
	 */

	public Vector getVariations() {
		System.out.println("starting generation in " + this.getClass());
		double s = System.currentTimeMillis();
		v = new Vector();
		final char[] alphabetChars = a.toCharArray();
		final char[] result = new char[n];
		int al = a.length();
		variations(n - 1, alphabetChars, result, al);
		double e = System.currentTimeMillis() - s;
		System.out.println("generation done." + " took " + e + " ms");
		System.out.println();
		return v;
	}

	private void variations(int pos, char[] alphabet, char[] result, int al) {
		for (int i = 0; i < al; i++) {
			result[pos] = alphabet[i];
			if (pos > 0) {
				variations(pos - 1, alphabet, result, al);
			} else {
				v.add(new String(result));
				//System.out.println(new String(result));
				//count++;
			}
		}
	}

}