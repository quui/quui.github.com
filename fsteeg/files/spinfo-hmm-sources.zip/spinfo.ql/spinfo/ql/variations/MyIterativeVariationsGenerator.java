/**
 * Created on 16.11.2004
*/
package spinfo.ql.variations;

import java.util.Vector;

/**
 * @author Fabian Steeg
 */
public class MyIterativeVariationsGenerator implements IVariationsGenerator {

	private String a;
	private int n;
	public MyIterativeVariationsGenerator(String a, int n){this.a=a;this.n=n;}

	/* (non-Javadoc)
	 * @see spinfo.ql.variations.IVariationsGenerator#getVariations()
	 */
	public Vector getVariations() {
		System.out.println("starting generation in " + this.getClass());
		double s = System.currentTimeMillis();
		int l = a.length();
		int allPos = (int) Math.pow(l, n);
		char[][] all = new char[allPos][n];
		for (int x = 0; x < n; x++) {
			int t2 = (int) Math.pow(l, x); // 1, 3, 9, 27... if a.length=3
			for (int p1 = 0; p1 < allPos; /*p1++*/) {
				for (int al = 0; al < l; al++) {
					for (int p2 = 0; p2 < t2; p2++) {
						all[p1][x] = a.charAt(al);
						p1++;
					}
				}
			}
		}
		Vector allV = new Vector();
		for (int i = 0; i < all.length; i++) {
			StringBuffer buf = new StringBuffer();
			for (int j = 0; j < all[i].length; j++) {
				buf.append(all[i][j]);
				//System.out.print(all[i][j]);
			}
			allV.add(buf.toString());
		}
		double e = System.currentTimeMillis() - s;
		System.out.println("generation done." + " took " + e + " ms");
		System.out.println();
		return allV;
	}

}
