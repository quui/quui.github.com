/**
 * Created on 16.11.2004
*/
package spinfo.ql.variations;

import java.util.Vector;
	
/**
 * @author Fabian Steeg
 */
public class IterativeVariationsGeneratorFromNet
		implements
			IVariationsGenerator {
	private String a;
	private int n;
	public IterativeVariationsGeneratorFromNet(String a, int n){this.a=a;this.n=n;}

	/* (non-Javadoc)
	 * @see spinfo.ql.variations.IVariationsGenerator#getVariations()
	 */
	public Vector getVariations() {
		System.out.println("starting generation in " + this.getClass());
		double s = System.currentTimeMillis();
		Vector v = new Vector();
		final char[] alphabetChars = a.toCharArray();
		final int alphabetSize = alphabetChars.length;
		final char[] chars = new char[n];
		final int[] values = new int[n];

		for (int index = 0; index < n; index++) {
			chars[index] = alphabetChars[0];
		}
		// a label
		outer : for (;;) {
			v.add(new String(chars));
			//System.out.println(new String(chars));
			//count++;
			for (int index = n - 1; index >= 0; index--) {
				values[index]++;

				if (values[index] < alphabetSize) {
					chars[index] = alphabetChars[values[index]];
					break;
				} else {
					if (index == 0) {
						break outer;
					} else {
						values[index] = 0;
						chars[index] = alphabetChars[0];
					}
				}
			}
		}
		double e = System.currentTimeMillis() - s;
		System.out.println("generation done." + " took " + e + " ms");
		System.out.println();
		return v;
	}
}
