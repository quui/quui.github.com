package spinfo.ql.variations;

import java.util.Vector;
/**
 * @author Fabian Steeg
 * Created on 16.11.2004
*/
public interface IVariationsGenerator {
	public Vector getVariations();
}
