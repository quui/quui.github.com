/**
 * Created on 06.12.2004
 */
package spinfo.ql;

import spinfo.ql.hmm.ViterbiHMM;

/**
 * uses hard-coded matrices and viterbi
 * @author Fabian Steeg
 */
public class ViterbiTagger {
public static void main(String[] args) {
		final String tagset = "det n v period";
		final String lexicon = "the bear sleeps .";
		final String input = "the bear sleeps . the bear .";
		
		// vert: tagset, horiz: tagset
		double[][] A = new double[][]
									{{0, 40000, 0, 0},
									{1000, 10000, 1000, 20000}, 
									{6000, 1500, 100, 1400},
									{9000, 1000, 10000, 0}};
		// vert: lexicon, horiz: tagset
		double[][] B = new double[][]
									{{10000, 0, 0, 0}, 
									{0, 200, 100, 0},
									{0, 200, 200, 0}, 
									{0, 0, 0, 20000}};
		ViterbiHMM hmm = new ViterbiHMM(tagset, lexicon,
				input, A, B,true);
		System.out.println("most probable tagsequence for input '" + input
				+ "' is '" + hmm.getMostProbableSequence() + "'.");
	}}