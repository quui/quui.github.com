/**
 * Created on 17.11.2004
 */
package spinfo.ql;

import java.util.HashMap;
import java.util.Vector;

import spinfo.ql.hmm.GenerateAndTestHMM;
/**
 * @author Fabian Steeg 
 * uses generate-and-test
 */
public class Dendrochnology {
	public static void main(String[] args) {
		final String hiddenAlphabet = "HC";
		final String observableAlphabet = "SML";
		final String observation = "SMSL";
		double[][] A = new double[][]{{0.7, 0.3}, {0.4, 0.6}};
		double[][] B = new double[][]{{0.1, 0.4, 0.5}, {0.7, 0.2, 0.1}};
		double[] start = new double[]{0.6, 0.4};
		GenerateAndTestHMM hmm = new GenerateAndTestHMM(hiddenAlphabet, observableAlphabet, observation, A,
				B, start);
		hmm.setBenchmarking(false);
		// generate and test approach:
		Vector sequences = hmm.generateAllSequences();
		HashMap map = hmm.computeProbabilities(sequences);
		String mostProbableFull = hmm.getBestForFullSequence(map);
		double sum = hmm.getSumOfAllSequences(map);
		System.out.println("observation is: " + observation);
		System.out
				.println("'generate and test' solution for problem 1 (sum of all probabilities) is: "
						+ sum);
		System.out
				.println("'generate and test' solution for problem 2 (most probable complete sequence) is: '"
						+ mostProbableFull
						+ "' with "
						+ ((Double) map.get(mostProbableFull)).doubleValue());
		System.out.println();
		System.out.println("'generate and test' solution via computeMost... is: " + hmm.getMostProbableSequence());
	}
}