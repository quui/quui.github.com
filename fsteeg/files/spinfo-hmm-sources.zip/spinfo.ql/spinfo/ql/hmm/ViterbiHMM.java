/**
 * Created on 06.12.2004
 */
package spinfo.ql.hmm;

import java.util.Arrays;

/**
 * @author Fabian Steeg
 */
public class ViterbiHMM extends AbstractHMM {
    /**
     * @param a
     *            the hidden alphabet
     * @param obsA
     *            the observable alphabet
     * @param obs
     *            the observed sequence
     * @param A
     *            transitions observabl to hidden
     * @param B
     *            transitions hidden to hidden
     */
    private double[][] delta;

    private int[][] psi;

    private String[] hiddenAlphabet;

    private String[] observableAlphabet;

    private String[] observation;

    private boolean absoluteValues;

    public ViterbiHMM(String a, String obsA, String obs, double[][] A,
            double[][] B, boolean absoluteValues) {
        super(a, obsA, ". " + obs, A, B);
        this.absoluteValues = absoluteValues;
    }

    public String getMostProbableSequence() {
        init();
        induct();
        System.out.println("Delta:");
        ViterbiMatrixTools.printMatrix(delta);
        System.out.println();
        System.out.println("Psi:");
        ViterbiMatrixTools.printMatrix(psi);
        System.out.println();
        return getResult();
    }

    /**
     * fill delta with 0.0 except for the starting 1.0 fill psi with -1
     */
    private void init() {
        hiddenAlphabet = a.split("\\s");
        observableAlphabet = obsA.split("\\s");
        observation = obs.split("\\s");
        delta = new double[hiddenAlphabet.length][observation.length];
        for (int i = 0; i < delta.length; i++) {
            Arrays.fill(delta[i], 0.0);
        }
        delta[delta.length - 1][0] = 1.0;
        psi = new int[hiddenAlphabet.length][observation.length - 1];
        for (int i = 0; i < psi.length; i++) {
            Arrays.fill(psi[i], -1);
        }
    }

    /**
     * computes delta, the matrix with probabilities
     */
    private void induct() {
        // for each word in input, except starting period
        for (int i = 1; i < observation.length; i++) {
            // for each tag in the tagset we now compute the entry for delta
            for (int j = 0; j < hiddenAlphabet.length; j++) {
                double prevTagMax = ViterbiMatrixTools.getMaximimumForCol(
                        i - 1, delta);
                // lookup the word
                int lexIndex = getIndex(observation[i], observableAlphabet);
//                System.out.println("in induct lexIndex: " + lexIndex);
                double prob = getProbForWordToTag(lexIndex + 1, j, B, A);
                double res = prevTagMax * prob;
                delta[j][i] = res;
                if (res > 0.0)
                    psi[j][i - 1] = ViterbiMatrixTools
                            .getIndexOfMaximimumForCol(i - 1, delta);
            }

        }
    }

    private double getProbForWordToTag(int i, int j, double[][] b, double[][] a) {
        //delta has the leading period, therefore - 1 for previous
//        System.out.println("trying on this matrix:");
//        ViterbiMatrixTools.printMatrix(delta);
        int prevIndex = ViterbiMatrixTools.getIndexOfMaximimumForCol(i - 1,
                delta);
        //b doesn have th eleading p, therefore -1 for recent
        if (absoluteValues)
            return (b[i - 1][j] / ViterbiMatrixTools.getSumForCol(j, B))
                    * (A[prevIndex][j] / ViterbiMatrixTools.getSumForRow(
                            prevIndex, A));
        else {
            
            return (b[i - 1][j]) * (A[prevIndex][j]);
        }
    }

    /**
     * returns the result after retrieving it from the psi-matrix
     */
    private String getResult() {
        String[] resultArray = new String[psi[0].length];
        int lastIndexInPsi = ViterbiMatrixTools.getIndexOfMaximimumForCol(
                delta[0].length - 1, delta);
        if (lastIndexInPsi == -1) {
            System.out.println("no tag-sequence found for input, exit.");
            System.exit(0);
        }
        int lastValueInPsi = psi[lastIndexInPsi][psi[0].length - 1];
        String lastTag = hiddenAlphabet[lastIndexInPsi];
        resultArray[resultArray.length - 1] = lastTag;
        //retrieve other tags:
        for (int i = psi[0].length - 2; i >= 0; i--) {
            resultArray[i] = hiddenAlphabet[lastValueInPsi];
            lastValueInPsi = psi[lastValueInPsi][i];
        }
        StringBuffer resultString = new StringBuffer();
        for (int i = 0; i < resultArray.length; i++) {
            resultString.append(resultArray[i]);
            if (i < resultArray.length - 1)
                resultString.append(" ");
        }
        return resultString.toString();
    }

    /**
     * @param string
     *            the string to search
     * @param observableStates
     *            the String[] to search in
     * @return the index of string in observableStates
     */
    private int getIndex(String string, String[] observableStates) {
        for (int i = 0; i < observableStates.length; i++) {
            if (string.equals(observableStates[i]))
                return i;
        }
        System.out.println("word not found in lexicon, exit.");
        System.exit(0);
        return -1;
    }
}