/**
 * Created on 06.12.2004
*/
package spinfo.ql.hmm;

/**
 * @author Fabian Steeg
 */
public abstract class AbstractHMM {
	protected String a;
	protected int n;
	protected String obsA;
	protected String obs;
	protected double[][] A;
	protected double[][] B;
	protected String mostProbableSequence; 
	public AbstractHMM(String a, String obsA, String obs, double[][] A, double[][] B) {
		this.a = a;
		this.n = obs.length();
		this.obsA = obsA;
		this.obs = obs;
		this.A = A;
		this.B = B;
	}
	public abstract String getMostProbableSequence();
}
