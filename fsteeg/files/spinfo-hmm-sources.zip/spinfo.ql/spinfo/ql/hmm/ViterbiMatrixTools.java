/**
 * Created on 08.12.2004
 */
package spinfo.ql.hmm;

import java.text.NumberFormat;

/**
 * @author Fabian Steeg
 */
public class ViterbiMatrixTools {

	public static void printMatrix(double[][] matrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				Double d = new Double(matrix[i][j]);
				String myString = NumberFormat.getInstance().format(
						matrix[i][j]);
				//fill up with blanks:
				if (myString.length() < 5) {
					for (int k = myString.length(); k < 5; k++) {
						myString = myString + " ";
					}
				}
				System.out.print(myString + "   ");
			}
			System.out.println();
		}
	}
	public static void printMatrix(int[][] matrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				if (matrix[i][j] >= 0)
					System.out.print(" ");
				System.out.print(matrix[i][j] + "   ");
			}
			System.out.println();
		}
	}
	public static double getSumForCol(int i, double[][] matrix) {
		double sum = 0;
		for (int j = 0; j < matrix.length; j++) {
			sum = sum + matrix[j][i];
		}
		return sum;
	}
	public static double getSumForRow(int i, double[][] matrix) {
		double sum = 0;
		for (int j = 0; j < matrix[i].length; j++) {
			sum = sum + matrix[i][j];
		}
		return sum;
	}
	public static int getIndexOfMaximimumForCol(int i, double[][] matrix) {
	  
		int maxIndex = -1;
		double maxValue = -1.0;
		for (int j = 0; j < matrix.length; j++) {
			if (/*j >=0&&j<matrix.length&&i >=0&&i<matrix[i].length&&*/matrix[j][i] > maxValue) {
				maxIndex = j;
				maxValue = matrix[j][i];
			}
		}
		return maxIndex;
	}
	public static int getIndexOfMaximimumForCol(int i, int[][] matrix) {
		int maxIndex = -1;
		int maxValue = -1;
		for (int j = 0; j < matrix.length; j++) {
			if (matrix[j][i] > maxValue) {
				maxIndex = j;
				maxValue = matrix[j][i];
			}
		}
		return maxIndex;
	}
	public static double getMaximimumForCol(int i, double[][] matrix) {
		double maxValue = 0.0;
		for (int j = 0; j < matrix.length; j++) {
			maxValue = Math.max(maxValue, matrix[j][i]);
		}
		return maxValue;
	}

}