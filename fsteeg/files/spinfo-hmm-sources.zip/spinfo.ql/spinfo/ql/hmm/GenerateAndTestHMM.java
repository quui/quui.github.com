/**
 * Created on 17.11.2004
 */
package spinfo.ql.hmm;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import spinfo.ql.variations.IVariationsGenerator;
import spinfo.ql.variations.IterativeVariationsGeneratorFromNet;
import spinfo.ql.variations.MyIterativeVariationsGenerator;
import spinfo.ql.variations.RecursiveVariationsGeneratorFromNet;

/**
 * @author Fabian Steeg
 */
public class GenerateAndTestHMM extends AbstractHMM{
	
	private double[] start;
	private boolean benchmarking = false;
	public GenerateAndTestHMM(String a, String obsA, String obs, double[][] A, double[][] B, double[] start) {
		super(a,obsA,obs,A,B);
		this.start = start;
	}
	public String getMostProbableSequence() {
		Vector sequences = generateAllSequences();
		HashMap map = computeProbabilities(sequences);
		return getBestForFullSequence(map);
	}
	/**
	 * @return a hashmap with sequences as keys (String) and their probability
	 *         as value (Long)
	 */
	public Vector generateAllSequences() {
		IVariationsGenerator gen;
		Vector hiddenModels;
		if (!benchmarking) {
			gen = new MyIterativeVariationsGenerator(a, n);
			hiddenModels = gen.getVariations();
		} else {
			gen = new IterativeVariationsGeneratorFromNet(a, n);
			hiddenModels = gen.getVariations();

			gen = new IterativeVariationsGeneratorFromNet(a, n);
			hiddenModels = gen.getVariations();

			gen = new RecursiveVariationsGeneratorFromNet(a, n);
			hiddenModels = gen.getVariations();

			gen = new RecursiveVariationsGeneratorFromNet(a, n);
			hiddenModels = gen.getVariations();

			gen = new MyIterativeVariationsGenerator(a, n);
			hiddenModels = gen.getVariations();

			gen = new MyIterativeVariationsGenerator(a, n);
			hiddenModels = gen.getVariations();
		}
		return hiddenModels;
	}
	/**
	 * naive computations of a seq prob. problem: takes 2TNpowT multiplic.
	 * 
	 * @param hiddenModels
	 * @return
	 */
	public HashMap computeProbabilities(Vector hiddenModels) {
		HashMap map = new HashMap();
		for (Iterator iter = hiddenModels.iterator(); iter.hasNext();) {
			String seq = (String) iter.next();
			char[] chars = seq.toCharArray();
			double prob = start[a.indexOf("" + chars[0])];
			for (int i = 0; i < chars.length; i++) {
				if (i == 0)
					prob = prob
							* B[a.indexOf("" + chars[i])][obsA.indexOf(obs
									.charAt(i))];
				else
					prob = prob
							* A[a.indexOf("" + chars[i - 1])][a.indexOf(""
									+ chars[i])]
							* B[a.indexOf("" + chars[i])][obsA.indexOf(obs
									.charAt(i))];
			}
			map.put(seq, new Double(prob * 100));
		}
		return map;
	}
	/**
	 * @param map
	 *            with all sequences and probabilities
	 * @return the String with the highest overall probability in map
	 */
	public String getBestForFullSequence(HashMap map) {
		double max = 0;
		String res = "";
		for (Iterator iter = map.keySet().iterator(); iter.hasNext();) {
			String string = (String) iter.next();
			double rec = ((Double) map.get(string)).doubleValue();
			if (rec > max) {
				max = rec;
				res = string;
			}
		}
		return res;
	}
	public double getSumOfAllSequences(HashMap map) {
		double res = 0;
		for (Iterator iter = map.keySet().iterator(); iter.hasNext();) {
			String string = (String) iter.next();
			double rec = ((Double) map.get(string)).doubleValue();
			res = res + rec;
		}
		return res;
	}
	/**
	 * @param c
	 */
	public void setBenchmarking(boolean c) {
		this.benchmarking = c;
	}
}