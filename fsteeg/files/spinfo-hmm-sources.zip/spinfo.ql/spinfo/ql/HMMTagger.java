/**
 * Created on 04.01.2005
 */
package spinfo.ql;

import java.util.HashMap;
import java.util.Iterator;

import spinfo.ql.hmm.MatrixGenerator;
import spinfo.ql.hmm.ViterbiHMM;

/**
 * generates matrices (jelinek/kupiec and pseudo-random) and uses viterbi
 * @author Fabian Steeg
 */
public class HMMTagger {

    public HMMTagger() {
        super();
    }

    public static void main(String[] args) {
        HashMap lex = new HashMap();
        
        //kupiec (words with common category-sets make a category of their own): 
        //better for small trainingsets (since they are then distinguished from the
        //pure members of the single classes? i.e. having 'nv v' instead of 'v v'?)
        lex.put("fliegen", "vn");
        lex.put("schichten", "vn");
        
        lex.put("schleichen", "v");
        lex.put("nahrung", "n");
        lex.put("die", "det,rp");
        lex.put(".", "period");
        
        StringBuffer lexBuf = new StringBuffer();
        for (Iterator iter = lex.keySet().iterator(); iter.hasNext();) {
            String element = (String) iter.next();
            lexBuf.append(element);
            if(iter.hasNext())
                lexBuf.append(" ");
        }
        
        String tagset = "det rp vn v n period";
        String corpus = "die fliegen fliegen. die fliegen schleichen. die, die nahrung schichten fliegen. die fliegen schichten die nahrung schichten.";
        MatrixGenerator gen = new MatrixGenerator(lex, corpus,
                tagset);
        double[][] B = gen.getMatrix();
        //adjust this value vary the random filled matrix: 
        double[][] A = gen.getRandomMatrix(0.01);
        
		final String lexicon = lexBuf.toString(); // also internally  the order is as traversed with iter
		final String input = "schichten die fliegen die nahrung . die fliegen schleichen .";
		
		ViterbiHMM hmm = new ViterbiHMM(tagset, lexicon,
				input, A, B,true);
		String[] in = input.split(" ");
		String[] re = hmm.getMostProbableSequence().split(" ");
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < in.length; i++) {
            buf.append(in[i]+":"+re[i]+" ");
        }
		System.out.println(buf.toString());
    }
}