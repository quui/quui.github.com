import java.io.*;
import searchDesign.*;

public class Main {


	public static void main(String args[]) throws java.io.IOException{

        // Settings.user ist ein global definierter User, u.a. zur Ausgabe von Questions und Messages
        Settings.user = new UserData(new ConsoleTalk());

        // Hauptprogramm:
        try {
          // Settings.user wird an den Konstruktor von Gui �bergeben, weil die I/O-Schnittstelle 
          // des Programms dort auf die Gui umgestellt wird
            Gui gui = new Gui(Settings.user);
        }
        catch (java.lang.OutOfMemoryError o) {
            Settings.user.talk.error("Nicht gen�gend Arbeitsspeicher verf�gbar:\n" + o);
        }
        catch (java.lang.Exception e) {
            Settings.user.talk.error("Eine Exception ist aufgetreten:\n" + e);
            e.printStackTrace();
        }
        catch (java.lang.Error f) {
            Settings.user.talk.error("Ein schwerwiegender Fehler ist aufgetreten:\n" + f);
            f.printStackTrace();
        }
    }


}