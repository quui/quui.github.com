package searchDesign;
/**
 *
 * <p>Beschreibung: Wird von den beiden alternativen Direktzugriffsstrukturen
 * StorageTable und StorageTree implementiert.</p>
 * @version 1.0
 */
public interface StorageInterface {

        /**
         * Erzeugt aus der Datenstruktur ein Array mit Data-Objekten und gibt
         * dieses zur�ck.
         *
         * @return Data-Array
         */
	public Data[] asDataArray();

	/**
         * F�gt newData in die Direktzugriffsstruktur ein. Fall der Key von
         * newData bereits darin enthalten ist, wird die Methode add von
         * Data aufgerufen.
         *
         * @param newData Das neu einzuf�gende Data-Objekt
         */
	public void put(Data newData);

        /**
         * Gibt den Wert von key zur�ck, oder null, wenn key nicht in der
         * Direktzugriffsstruktur enthalten ist
         *
         * @param key Der Schl�ssel, dessen Wert gesucht wird
         * @return Der Wert des gefundenen Schl�ssels
         */
	public Object get(Object key);

	/**
         * gibt die Anzahl der gespeicherten Keys zur�ck
         * @return die Anzahl der gespeicherten Keys
         */
	public int size();

}
