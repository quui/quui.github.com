package searchDesign;

import java.io.*;

/**
 *
 * <p>Beschreibung: Ein Crawler  speichert die Pfade der Text-Dateien (.txt, .html und .htm),
 * die sich im �bergebenen Verzeichnis und in seinen Unterverzeichnissen befinden.
 * Er geht daf�r durch das ihm in der Methode initialize �bergebene Startverzeichnis
 * und dessen Verzeichnisse rekursiv durch und speichert die Pfade der darin gefundenen
 * Dateien in einer geeigneten Datenstruktur ab.
 * Gibt nach dem Einlesen der Filenamen eine Meldung �ber die Zahl der gefundenen
 * Text-Dateien aus.</p>
 * @version 1.0
 */

public interface CrawlerInterface {

  /**
   * Initialisierungsfunktion
   * �bergibt das Startverzeichnis f�r die Suche nach Dokumenten.
   * @param path der Pfad zum zu indizierenden Verzeichnis
   * @throws FileNotFoundException Wenn der Pfad ung�ltig ist.
   */
    public void initialize (String path) throws FileNotFoundException;

    /**
     * Gibt ein String Array zurueck, das die kompletten Pfade zu allen
     * Text- und HTML-Dateien enthaelt, die in dem zu scannenden
     * Verzeichnis liegen.
     * @return ein String Array mit Pfaden
     */

    public String[] getFiles();
}