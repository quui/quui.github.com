package searchDesign;

import java.io.*;
import java.util.Vector;
import java.util.Enumeration;

////////////////////////////////////////////////////////////////////
/**
*
* <p>Beschreibung: Die QueryEngine bearbeitet die Suchanfragen. </p>
* @author Fabian Steeg
*/
////////////////////////////////////////////////////////////////////

public class QueryEngine implements QueryEngineInterface {
    
    //   der  i n d e x
    private StorageInterface index;
    private Data[] indexAsArray; 
    
    //   die Pfade - zum Zuordnen von Dokumenten zu gefundenen
    //   DocumentData
    private Vector pfade;
    
    //   das file fuer die Ausgabe der Ergebnisse
    private FileOutputStream rausFile;
    
    //   alle suchworte mit UND-Verknuepfung
    private Vector suchworte;
    
    //   alles suchworte in Ketten
    //   wird mit Vectoren bestueckt - einer pro kette
    private Vector alleSuchworteKette;
    
    //   Ergebnisse einer Suche ueber mehrere Ketten
    //   nur dann bestueckt - zum ermitteln derer mit 
    //   gleicher ID
    private Vector richtigeDDs;
    
    //   fuer die Ergebnisse der Und suche, wenn eine
    //   Kombination und/kette gesucht wurde
    private Vector richtigeDoksUND;
    //   dto., fuer Kette
    private Vector richtigeDoksKette;
    
    //   die letztendlich richtigen DDs, wird direkt besturckt,
    //   wenn keine Kombination vorliegt
    private Vector richtigeDoks;
    
    //   fuer die Suche nach aufeinanderfolgende Worte bei Ketten
    private Vector gefundeneDD;
    
    //////////////////////////////////////////////////////////////////////////
    /**
    * Initialisierungsmethode:
    * Liest die Indexdatei indexFile ein und rekonstruiert daraus den
    * invertierten Index. Um Rankingberechnungen und Kontextausgaben machen zu
    * k�nnen, ben�tigt die QueryEngine die Informationen aus der Datei
    * docMapFile, die beim Indizieren vom Parser angelegt wurde. In der Datei
    * resultFile werden die Suchergebnisse gespeichert.
    *
    * @param indexFile  Pfad zur Indexdatei
    * @param docMapFile Pfad zur DocMap-Datei
    * @param resultFile Pfad zur Ausgabedatei
    */
    ///////////////////////////////////////////////////////////////////////////
    
    public void initialize (String indexFile, String docMapFile, String resultFile){
        try{   
        
        //   lesen des Index
        FileInputStream inFile = new FileInputStream(indexFile);
        ObjectInputStream sIn = new ObjectInputStream(inFile);
       
        index =  (StorageInterface) sIn.readObject();
        Settings.user.talk.message("'Index' - Datei eingelesen (deserialisiert).");
        
        //   index als Array
        indexAsArray = index.asDataArray();
      
        //   docMap einlesen
        LineNumberReader ini; // Zum zeilenweisen Einlesen der Datei "docmap.txt"
        ini = new LineNumberReader(new BufferedReader(new FileReader(docMapFile)));
        pfade = new Vector(20,5);
        String in;
        ini.readLine(); //   die Zeile mit der Dok - Zahl ueberlesen
        while ((in = ini.readLine()) != null){
            pfade.add(in);      
            ini.readLine(); //   die Zeile mit der Wortzahl ueberlesen
        }
        Settings.user.talk.message("'DocMap' - Datei eingelesen.");
        
        //   resultFile anlegen
        rausFile = new FileOutputStream(resultFile, true);
        Settings.user.talk.message("");
        Settings.user.talk.message("Datei \"" + resultFile +"\" zum Speichern der Ergebnisse angelegt.");
        Settings.user.talk.message("");
        //throw new NullPointerException();
        }
        catch (Throwable erx) { // Error or Exception
            Settings.user.talk.error("Fehler bei der Initialisierung der QueryEngine:\n" + erx + "\nGenaueres finden Sie in der Programmausgabe");
            erx.printStackTrace();
        }
    }
    
    ////////////////////////////////////////////////////////////////////////////
    /**
    * Bearbeitet eine Suchanfrage.
    * Term ist die Benutzereingabe, welche eine beliebige Kombination von
    * Woertern und/oder Wortketten enthaelt. Eine Wortkette bezeichnet
    * aufeinander folgende Woerter in doppelten Anfuehrungszeichen,
    * z.B. "boese Hexe". term wird in seine einzelnen Bestandteile geparst.
    * Es muessen alle Dokumente ermittelt werden, die alle Woerter des Terms
    * enthalten. 
    * <br>
    * Hier sollte man sich alle Dokumente merken, in denen der
    * erste Term enthalten ist, und die Schnittmenge von dieser
    * Dokumentenmenge und den Dokumentenmengen der weiteren Terme der
    * Suchanfrage bilden. 
    * <br> 
    * Bei der Behandlung von Wortketten muss verifiziert
    * werden, dass die einzelnen Woerter einer Wortkette adjazent sind. Die
    * noetigen Informationen daf�r sind in den Fundstellen enthalten. 
    * <br>
    * F�r die
    * Ausgabe werden die ermittelten Dokumente nach dem Ranking mit Hilfe von
    * Quicksort sortiert. Anschlie�end gibt processQuery die Suchergebnisse
    * sowohl auf dem Bildschirm als auch in die Ausgabedatei resultFile aus. 
    * Die Ausgabe der KeyWords im Kontext geschieht mittels eines RandomAccessFiles 
    * auf die entsprechenden Dokumente. 
    * F�r die Ausgabe wird der Originaltext leicht aufbereitet.
    *
    * @param term Die eingegebene Suchanfrage
    */
    ///////////////////////////////////////////////////////////////////////////////
    
    public void processQuery(String term){
        //Settings.user.talk.message("Beginne Suche nach >>"+term+"<< ...");
        //Settings.user.talk.message("");
        //   eleminierung von Gross/Kleinschrift 
        term = term.toUpperCase();
        
        //   zwei Vectoren zum aufnehmen der Suchworte
        //   nach dem Parses des Suchterms. 
        
        //   initialisierung hier da nach jeder Suchanfrage neu
        suchworte = new Vector(1,3);
        alleSuchworteKette = new Vector(1,3);
        
        //   Vectoren fuer die Ergebnisse der Suche
        richtigeDoksUND = new Vector(3,2);
        richtigeDoksKette = new Vector(3,2);
        richtigeDoks = new Vector(3,2);
        
        richtigeDDs = new Vector(3,2);
        
        //   den anfragestring parsen
        parseTerm(term);
        
        //   boolean fuer den fall dass UND und Kette kombiniert werden
        boolean kombi = false;

        try{
        
        //   entscheiden, welche Suchmethode angewndt werden soll
        
        //   wenn beide Vectoren Inhalt haben,
        //   liegt eine Kombination UND/Kette vor.
        
        //   in dem fall bestuecken die suchfunktionen 
        //   nicht direkt den Vector mit den Ergebnissen.
        
        if(suchworte.size() > 0 && alleSuchworteKette.size() > 0)
            kombi = true;
            
        //   wenn nur ein wort gesucht wird, eigene funktion aufrufen
        if(suchworte.size() == 1 && alleSuchworteKette.size() == 0){
            sucheEinWort(term);
        }    
        
        //   ansonsten beide suchworte-Vectoren absuchen
        else{
        
            if(alleSuchworteKette.size() > 0){
               sucheAllesKette(kombi);
            }
            
            if(suchworte.size() > 0){
                sucheUND(kombi);
            }
            
        }
        
        //   falls mehrere Ketten gesucht wurden,
        //   die Schnittmenge ermitteln...
        
        if(richtigeDDs.size() > 0){
        
            Enumeration z = richtigeDDs.elements();
            DocumentData rec = (DocumentData)z.nextElement();
            boolean alleGleicheID = false;
            while (z.hasMoreElements()){
                if(rec.compareTo(((DocumentData)z.nextElement()).getKey()) == 0)
                    alleGleicheID = true;
                else
                    alleGleicheID = false;
            }
            //   ... wenn gleich, zu den Ergebnissen
            if (alleGleicheID){
                if(kombi)
                    richtigeDoksKette.add(richtigeDDs.elementAt(0));
                else
                    richtigeDoks.add(richtigeDDs.elementAt(0));
            }
        }
        
        //   bei einer Kombination aus UND und Kette, muss 
        //   die Schnittmenge der Dokumente aus beiden 
        //   Ergebnismengen als Ergebnis bestimmt werden.
        
        if(kombi){
            Enumeration e = richtigeDoksUND.elements();
            while (e.hasMoreElements()){
                DocumentData recDD = ((DocumentData) e.nextElement());
                Enumeration f = richtigeDoksKette.elements();
                while (f.hasMoreElements()){
                    DocumentData toCompDD = (DocumentData) f.nextElement();
                    if (recDD.compareTo(toCompDD.getKey()) == 0)
                        richtigeDoks.add(toCompDD);
                }
                    
            }
        }
        //   falls es Ergebnisse gibt, diese ranken und ausgeben
        int riDokAnzahl = richtigeDoks.size();
        int alleDoks = pfade.size();
        DocumentData[] gerankteDDs = new DocumentData[riDokAnzahl];
        if(riDokAnzahl > 0){
            Enumeration g = richtigeDoks.elements();
            String meldung = "Suchergebnisse fuer: " + ">>" + term.toLowerCase() + "<<";
            Settings.user.talk.message(meldung);
            int l = meldung.length();
            for (int c = 0;c<l;c++){
                rausFile.write(meldung.charAt(c));
            }
            rausFile.write(13); rausFile.write(10);
            int zaehlerFuersArray = 0;
            while (g.hasMoreElements()){
                DocumentData nextDD = (DocumentData)g.nextElement();
                //   Funktion zur Ausgabe mit Kontext aufrufen
                rankDD(nextDD, richtigeDoks, alleDoks);
                gerankteDDs[zaehlerFuersArray] = nextDD;
                zaehlerFuersArray++;
                
            }
            
            quicksort52Do(gerankteDDs, 0, gerankteDDs.length-1);
            for(int i = 0;i<gerankteDDs.length;i++){
                gebeMitKontextAus((DocumentData)gerankteDDs[i], Settings.user.contextLength);
            }
            Settings.user.talk.message("....................................................................................");
            Settings.user.talk.message("");
            Settings.user.talk.message("");
            Settings.user.talk.message("....................................................................................");
            Settings.user.talk.message("Suche abgeschlossen, Ergebnisse auf Programmausgabe und Datei ausgegeben.");
            Settings.user.talk.message("....................................................................................");
            
        }
       
        //   ansonsten Meldung
        else
             Settings.user.talk.message(">>"+term+"<< wurde nicht gefunden!");
        
        }   
        
        catch (Throwable erx) { // Error or Exception
            Settings.user.talk.error("Fehler beim Bearbeiten einer Suchanfrage in der QueryEngine:\n" + erx + "\nGenaueres finden Sie in der Programmausgabe");
            erx.printStackTrace();
        }
        
    }
    /////////////////////////////////////////
    /**
    * Sucht ein einzelnes Wort
    * @param term Die eingegebene Suchanfrage
    */
    /////////////////////////////////////////
    
    private void sucheEinWort(String term) {
        
        //   wie in 3.6.3 verlangt, die eingentliche
        //   Suche binaer auf einem Array
        int ergS = existenceSearch(term, indexAsArray);
        if(ergS == -1)
            return;
        KeyData erg = (KeyData) indexAsArray[ergS];
        if(erg == null)
            return;
        else{
            StorageInterface sto = erg.getDocuments();
            Data [] doks = sto.asDataArray();
            for(int m = 0;m<doks.length;m++){
                    richtigeDoks.add(  doks[m]  );
            }
                    
        }
    }
    
    ////////////////////////////////////////////////////
    /**
    * Sucht mehrere Worte mit UND-Verknuepfung
    * @param kombi flag fuer Kombination von Ketten und 
    * UND - Anfragen
    */
    ////////////////////////////////////////////////////
    
    private void sucheUND(boolean kombi){
        int ergS;
        //   suche ueber mehrere Worte mit UND Verknuepfung;
        Enumeration e = suchworte.elements();
        Vector gefundeneDD = new Vector(3,2);
        while (e.hasMoreElements()){
            //   wie in 3.6.3 verlangt, die eingentliche
            //   Suche binaer auf einem Array
            ergS = existenceSearch( (String) e.nextElement(), indexAsArray);
            if (ergS == -1)
                return;
            KeyData gefunden = (KeyData) indexAsArray[ergS];
            if(suchworte.size() == 1){
                if(gefunden == null)
                    return;
                else{
                    StorageInterface sto = gefunden.getDocuments();
                    Data [] doks = sto.asDataArray();
                    for(int m = 0;m<doks.length;m++){
                        richtigeDoksUND.add(  doks[m]  );
                    }
                }
                return;    
            }
            if(gefunden != null)
                gefundeneDD.add(  gefunden );
        }
        
        Data[] erstesArray = (  ((KeyData)gefundeneDD.elementAt(0)).getDocuments().asDataArray());
        
        int laengeErstes = erstesArray.length;
        for (int i = 0; i<laengeErstes; i++){
            Integer aktID = (Integer) erstesArray[i].getKey();
            if (  enthaltenImRest(  aktID, gefundeneDD  )  ){
                if(kombi)
                    richtigeDoksUND.add(  erstesArray[i]  );
                else
                    richtigeDoks.add(  erstesArray[i]  );
            }
        }
    }
    
    ////////////////////////////////////////////////////
    /**
    * Sucht nach Wortketten
    * @param kombi flag fuer Kombination von Ketten und 
    * UND - Anfragen
    */
    ////////////////////////////////////////////////////
    
    private void sucheAllesKette(boolean kombi){
        Enumeration e = alleSuchworteKette.elements();
        boolean more = false;
        if(alleSuchworteKette.size() > 1)
            more = true;
        while (e.hasMoreElements()){
            sucheKette(kombi, (Vector) e.nextElement(), more);
        }
    }
    
    //////////////////////////////////////////////////////////////////
    /**
    * Sucht nach einer Wortkette
    * @param kombi flag fuer Kombination von Ketten und UND - Anfragen
    * @param in der Vector von Worten die adjezent sein sollen
    * @param boolean more, flag fuer Kombination mehrerer Ketten
    */
    //////////////////////////////////////////////////////////////////
    
    private void sucheKette(boolean kombi, Vector in, boolean more){
        
        KeyData gefunden = null;
        int ergS;
        int laenge = 0;
        Enumeration e = in.elements();
        gefundeneDD = new Vector(3,2);
        //   zunaechst worte suchen, DDs speichern
        while (e.hasMoreElements()){
           ergS = existenceSearch( (String) e.nextElement(), indexAsArray);
           if (ergS == -1)
                return;
           gefunden = (KeyData)indexAsArray[ergS];
           if(gefunden != null)
                gefundeneDD.add(  (gefunden)  );
        }
        
        //   nun schleife ueber gefundene DDs, genauer ueber
        //   den Vector aus DD Arrays. jeder array zu einem wort
        //   alle woerter muessen nachfolgend sein
        for(int k=0;k<gefundeneDD.size()-1;k++){
            boolean wars = false;
            Data[] erstesArray = ( ((KeyData)gefundeneDD.elementAt(k)).getDocuments().asDataArray()  );
            
            int laengeErstes = erstesArray.length;
            boolean ists = false;
            //   Schleife ueber die DDs eines Arrays
            DocumentData recData;
            
            for (int i = 0; i<laengeErstes; i++){
                DocumentData newDDFull = new DocumentData();
                recData = (DocumentData)erstesArray[i];
                newDDFull.initialize(((Integer)recData.getKey()).intValue(), 0, (short)0);
                int [] recPos = recData.getPositions();
                short[] recAbs = recData.getSpaces();
                //   schleife ueber die Positionen eines DDs
                for(int j = 0;j<recPos.length;j++){
                    int laenge2 = ((String)in.elementAt(k)).length();
                    ists = hatNachfolgerInKD(  recPos[j], k+1  ); //   rekursive Funktion aufrufen
                    if((ists)){
                        wars = true;
                        DocumentData newDD = new DocumentData();
                        newDD.initialize( ((Integer)recData.getKey() ).intValue(), recPos[j], recAbs[j]);
                        newDDFull.add(newDD); //   Fundstellen eines DD akkumulieren
                    }
                }
                if (wars){ 
                    //   das vollstaendig akkumulierte DD speichern
                    if(more){
                        richtigeDDs.add(  newDDFull);
                    }
                    else if(kombi){
                        richtigeDoksKette.add(  newDDFull  );
                    }
                    else
                        richtigeDoks.add(  newDDFull  );
                    }
                    
                    wars = false;
                }
               
            }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /**
    * Sucht rekursiv nach einem Nachfolger zu einer Position im Vector der gefundenen KDs.
    * @param pos, die Position des vorherigen Wortes
    * @param nextKD die Position zu durchsuchenden KD auf dem Vector mit den gefundenen Stellen
    * @return boolean, obs den Nachfolger gibt
    */
    ///////////////////////////////////////////////////////////////////////////////////////////////
    
    private boolean hatNachfolgerInKD(int pos, int nextKD){
        KeyData derRest = (KeyData)gefundeneDD.elementAt(nextKD);
        KeyData davor = (KeyData)gefundeneDD.elementAt(nextKD-1);
        int laenge = ((String)davor.getKey()).length();
        boolean ergebnis = false;
        Data[] recArray = ((KeyData)derRest).getDocuments().asDataArray();
        for(int j=0;j<recArray.length;j++){
            DocumentData recData = (DocumentData) recArray[j];
            int [] recPos = recData.getPositions();
            short[] recAbs = recData.getSpaces();
            int l = recPos.length;
            for(int i=0;i<l;i++){//
                if ((pos + laenge + recAbs[i]) == recPos[i]){//pos == recPos[i]-recAbs[i]
                    if(nextKD < gefundeneDD.size()-1)
                        ergebnis = hatNachfolgerInKD(recPos[i], nextKD+1);
                    else{
                        ergebnis = true; 
                        return ergebnis;
                    }
                }
                else
                    ergebnis = false;
            }
        }
        return ergebnis;
    }
    
    /////////////////////////////////////////////////////////////////////
    /**
    * Sucht nach Dokumenten mit einer bestimmte ID in den Suchergebnissen
    * @param id, die gesuchte Document ID
    * @param derRest, Vector mit den Suchergebnissen
    * @return boolean, ob die ID enthalten ist
    */
    /////////////////////////////////////////////////////////////////////
    
    private boolean enthaltenImRest (Integer id, Vector derRest){
        Enumeration f = derRest.elements();
        boolean ergebnis = false;
        f.nextElement(); //   erstes ueberlesen
        while (f.hasMoreElements()){
            if((((KeyData)f.nextElement()).getDocuments()).get(id) != null)
                ergebnis = true;
            else
                ergebnis = false;
        }
        return ergebnis;
    }
    
    /////////////////////////////////////
    /**
    * Parst den Anfangsterm
    * @param term, die Sucheingabe
    */
    /////////////////////////////////////
        
    private void parseTerm(String term){
            boolean istWortkette = false;
            boolean warWortkette = false;
            boolean eineKetteFertig = false;
            
            Vector suchworteKette = new Vector(3,2);
            
            //   _________________   parsen des terms
            int l = term.length(); 
            int j = 0; //   zum behalten der wortanfaenge
            for (int i=0;i<l;i++){
               
                if((term.charAt(i) == '"') && !istWortkette){
                    istWortkette = true;
                    j++; //   das " ueberlesen
                }
                //   eine Kette wurde gelesen    
                else if((term.charAt(i) == '"') && istWortkette){
                    String teil = term.substring(j,i).trim();
                    suchworteKette.add(teil);
                    istWortkette = false;
                    alleSuchworteKette.add(suchworteKette);
                    suchworteKette=new Vector(3,2);
                    warWortkette = true;
                    j = i+1; //   das " ueberlesen
                }
                
                //  Wort (in Kette oder UND-Verknuepfung) gelesen
                else if(term.charAt(i) == ' ' && !warWortkette ){
                    String teil;
                    teil = term.substring(j,i).trim();
                    if(istWortkette)
                        suchworteKette.add(teil);
                    else
                        suchworte.add(teil);
                    j = i+1;
                }
                
                //   Leerzeichen nach einer Kette ueberlesen
                else if(term.charAt(i) == ' ' && warWortkette ){
                    j=i+1;
                    warWortkette = false;
                    eineKetteFertig = true;
                }
                
                //   letztes Wort, nicht in einer Kette speichern
                else if(i == term.length()-1){ //   letztes wort, keine Kette
                    String teil = term.substring(j).trim();
                    suchworte.add(teil);
                }
            }
        }
    
    //////////////////////////////////////////////////////
    /**
    * Binaere Suche auf Data[]
    * @param value das suchwort
    * @param values das Data[], auf dem gesucht werden soll
    * @return position des gesuchten Wortes als int oder -1
    */
    ///////////////////////////////////////////////////////
            
    static int existenceSearch(String value, Data[] values) {

        // Gibt den Index zur�ck, an dem der Wert value gefunden wurde, andernfalls -1.

        // Der Parameter v darf nicht null sein und mu� mindestens einen Wert enthalten.
        // Die enthaltenen Werte m�ssen aufsteigend sortiert sein.

        if ( values == null )
            throw new NullPointerException("Argument 2 (Data[] to search in) of QueryEngine.existenceSearch(String, Data[]) is null.");

        int n = values.length; //Anzahl Elemente
        if ( n == 0 )
            return -1;

        int mid, left, right;
        Data midVal;// 
                
        left = 0;
        right = n-1;

        do {
                    
            mid = (left+right)/2;
                   
            midVal = (values[mid]); 

            if ( value.compareTo(values[mid].getKey()) < 0 )
                right = mid-1;
            else if ( value.compareTo(values[mid].getKey()) > 0 )
                left = mid+1;
            else
                return mid;
        }
                
        while (left <= right);

        return -1;
    }
    /////////////////////////////////////////////////////////////
    /**
    * Bewertet ein DD, sollte nur auf ergebnisDDs angewandt werden
    * @param dd das zu rankende DocumentData
    * @param allDD der Vector mit allen Ergebnissen
    * @param allDoks die Anzahl aller Dokumente als int
    */
    /////////////////////////////////////////////////////////////
    
    private void rankDD (DocumentData dd, Vector allDD, int allDoks){
        double nk = 0;
        int[] pos = dd.getPositions();
        double tfjk = pos.length;
        nk = (double) allDD.size();
        double N = (double) allDoks;
        dd.setRank (tfjk * Math.log((double)N/nk));
    }
    
    ////////////////////////////////////////////////////////////
    /**
    * Gibt Funstellen mit Kontext aus, auf GUI und Datei
    * zunaechst wird ein kontext geschatzt und mit einem RAF auf 
    * der Datei gelesen. das so bestueckte byte[] wird auf ein
    * char[] kopiert, von dort mit dem entsprechenden Filter 
    * gelesen. die so geparsten worte kommen auf ein String[]
    * dere groesse kontextbreite + 2 + 1 und von dort ausgegeben
    * @param dd das auszugebende DocumentData
    * @param kontextBreite die gewuenschte Kontextbreite als int
    */
    ////////////////////////////////////////////////////////////
        
    static RandomAccessFile direkt;
    static File text;
    static int[] buffer;
    
    private void gebeMitKontextAus(DocumentData dd, int kontextBreite){
        try{
        // zur ermittlung der dateiart
        String tempString = ((String)pfade.elementAt( ((Integer)dd.getKey()).intValue() )).substring(((String)pfade.elementAt(((Integer)dd.getKey()).intValue())).length() - 4).toUpperCase();
        
        // den Pfad des aktuellen DD speichern
        int posi  =   ( (Integer) (  dd  ).getKey()  ).intValue();
        String path = (  (String)pfade.elementAt( posi   )  );
        
        Settings.user.talk.message("....................................................................................");
        
        for (int k = 0; k < 70; k++){
            rausFile.write( '.' );
        }
        
        //   schreibe Zeilenumbruch
        rausFile.write(13);
        rausFile.write(10);
        
        
        int[] tempPos = dd.getPositions();
        StringBuffer volleMeldung = new StringBuffer();
        String haeufigkeit = new String(tempPos.length +" Treffer in: ");
        volleMeldung = (volleMeldung.append(haeufigkeit)).append(path);
        //Settings.user.talk.message(tempPos.length +" Treffer in: ");
        Settings.user.talk.message(volleMeldung.toString());
        
        {
        int f = volleMeldung.length();
        for (int a = 0; a < f; a++){
            rausFile.write( volleMeldung.charAt(a) );
        }
        }
        
        String rankString = new String("- -  >  Bewertung: " + dd.getRank()+" ( = tfjk * log(N/nk) )" );
        Settings.user.talk.message(rankString);
        
        //   schreibe Zeilenumbruch
        rausFile.write(13);
        rausFile.write(10);
        {
            
        int f = rankString.length();
        for (int a = 0; a < f; a++){
            rausFile.write( rankString.charAt(a) );
        }
        }
        //   schreibe Zeilenumbruch
        rausFile.write(13);
        rausFile.write(10);
        
        text = new File(path);
        
        // if !exists...
        
        direkt = new RandomAccessFile(text, "r");
        int[] pos = dd.getPositions();
        
        //   Die Anzahl der auszugebenden Fundstellen auf
        //   GUI und Datei wird bestimmt duch das Menue in der GUI
        //   welches die Variable contextAmount in userData bestueckt.
        int anzahlStellen = Settings.user.contextAmount;
        
        int bis = Math.min(anzahlStellen, pos.length);
        //  ermittlung des Kontextes, ausgabe
        
        //   Schleife ueber auszugebende Fundstellen
        for(int m = 0;m< bis ;m++){
        
            String[] kontextArray = new String[(kontextBreite*2)+1];
            
            int buffSize;
            int geschaetzeWortgroesse;
            
            //Teilstring bilden zur Ermittlung der Endung schon oben gebildet
            
           
            if (tempString.compareTo(".TXT")==0) {
                geschaetzeWortgroesse = 15;// - kontextBreite;
                buffSize = 512;
            }
                    
            else{ //   bei HTML viel groesseren Kontext schaetzen....
                geschaetzeWortgroesse = 4096;// - kontextBreite;
                buffSize = (geschaetzeWortgroesse * 4) * kontextBreite;//4096*kontextBreite;
            }
            
            //   Kontext zunaechst schaetzen
            long direktPos = (long) pos[m];
            long laenge = (kontextBreite * geschaetzeWortgroesse);
            long nachVorn = (direktPos-1) - laenge;
            
            
            buffer = new int[buffSize];   
            long beg = Math.max((nachVorn), 0);
            
            //   offset des RAF auf Anfangsposition des Mittelwortes
            direkt.seek(Math.max(direktPos-1, 0));
            
            //   lesen bis zum Ende des geschaetzten Kontext
            
            if(laenge + geschaetzeWortgroesse >= buffSize)
                throw new ArrayIndexOutOfBoundsException("Pufferarray fuer den Kontext zu klein!");
                
            int bisEnde = (int)Math.min(laenge+geschaetzeWortgroesse, buffSize);
            
            for(int x = 0;x<bisEnde;x++){
                buffer[x] = direkt.read();
            }
            
            char[] test = new char[buffSize];
            
            for(int d=0;d<buffSize;d++)
                test[d] = (char) buffer[d];
                    
            //   buff nimmt ein Wort auf
            //StringBuffer buff = new StringBuffer();
            
            //   sammelt die Woerter des Kontextes
            Vector kontext = new Vector(20,5);
            
            {
            String wort = new String();
            Reader arrayRead = new CharArrayReader(test);
            Zeichenfilter textKontext;
            if (tempString.compareTo(".TXT")==0) {
                textKontext = new Textfilter(arrayRead);
            }
            else{
                textKontext = new Hypertextfilter(arrayRead);
                ((Hypertextfilter) textKontext).initialize("HTMLCodes.txt");
            }
            int ziel = kontextArray.length/2;
            while((wort = textKontext.nextWord(true)) != null   &&   ziel < kontextArray.length){
                kontextArray[ziel] = wort;
                ziel ++;
            }
            }
            
            buffer = new int[buffSize];   
                
            //   und offset des RAF aus Anfang setzen   
            direkt.seek(beg);
            
            //   Lesen von Anfang des ggeschatzten Kontext bis mitte
            
            if((laenge*2) + geschaetzeWortgroesse >= buffSize)
                throw new ArrayIndexOutOfBoundsException("Pufferarray fuer den Kontext zu klein!");
            
            //   lesen bis zum mittelpunkt des Kontext, dem gesuchten Wort
            
            int y;
            long bisMitte = Math.min(laenge -1, direktPos-1);
            for(y = 0;y<bisMitte;y++){
                buffer[y] = direkt.read();
            }
            
            test = new char[buffSize];
            
            for(int d=0;d<buffSize;d++)
                test[d] = (char) buffer[d];
                
            {
            String wort = new String();
            Reader arrayRead = new CharArrayReader(test);
            Zeichenfilter textKontext;
            if (tempString.compareTo(".TXT")==0) {
                textKontext = new Textfilter(arrayRead);
            }
            else{
                textKontext = new Hypertextfilter(arrayRead);
                ((Hypertextfilter) textKontext).initialize("HTMLCodes.txt");
            }
            
            //   gefundene worte auf vector
            while((wort = textKontext.nextWord(true)) != null){
                kontext.add(wort);
            }
            }
            
            //   die letzten n elemente des vecto von vorne
            //   aufs KontextArray setzen, n = kontextbreite
            
            int zielInArray = 0;
            int ab = kontext.size();
            for (int h=Math.max(ab-kontextBreite, 0);h<ab && h>= 0;h++){
                kontextArray[zielInArray] = (String) kontext.elementAt(h);
                zielInArray++;
            }
            
            
            //   nun die eigentliche Ausgabe des Kontexte:
            
                
            StringBuffer erg = new StringBuffer("... ");

            rausFile.write('.');  rausFile.write('.');  rausFile.write('.'); rausFile.write(' ');
            for(int j = 0; j<kontextArray.length;j++){
                if(kontextArray[j] != null){
                erg = erg.append((kontextArray[j] + " "));
                int e = ((String)kontextArray[j]).length();
                    for (int b = 0; b<e;b++){
                        rausFile.write(((String)kontextArray[j]).charAt(b));
                    }
                rausFile.write(' ');
                }
            }
            erg = erg.append(" ...");
            Settings.user.talk.message(erg.toString());
            rausFile.write(' ');  rausFile.write('.');  rausFile.write('.');  rausFile.write('.');
            rausFile.write(13);
            rausFile.write(10);
                    
        }
        rausFile.write(13);
        rausFile.write(10);
        direkt.close();
            
        }
        
        catch(Throwable erx){
            Settings.user.talk.error("Fehler bei der Ausgabe der Fundstellen in der QueryEngine:\n" + erx + "\nGenaueres finden Sie in der Programmausgabe");
            erx.printStackTrace();
        }
    }
    
    ///////////////////////////////////////////////////////////////
    /** 
    * Quicksort 52Do - Ein Quicksort entsprechend den Forderungen
    * von Aufgabe 52: Quicksort mit Wahl des ersten Element als Anker,
    * die zu tauschenden Objekte verden in do schleifen ermittelt.
    * (im Intervall left0+1 - right0). es wird wie bei wirth1 nur
    * bei left < right getauscht.
    * <br> 
    * die implementierung der tauschpartnersuche in do schleifen 
    * erfordert eine veraenderte initialisierung von left und
    * right. ein weiterschalten nach dem tausch ist nicht mehr 
    * noetig. da zuerst left weitergeschaltet wird, und erst dann 
    * die bedingung folgt, wird eine abbruchbedingung nach dem 
    * weiterschalten notwendig, die aber anscheinend auch in einer 
    * loesung mit while schleifen bei arrays ab etwa 60000 
    * elementen noetig ist. (sonst ArrayIndexOutOfBoundsException
    * bei der abfrage von a[left]) - wie das passiert ist mir ein 
    * raetsel, schliesslich muessten die neuen teilintervalle immer
    * aus mindestens zwei elementen bestehen.
    * <br> 
    * Veraenderungen gegenueber der Loesung mit While Schleifen 
    * gekennzeichnet mit ****
    *
    * <br>
    * <br>
    *
    * Quicksort 52While - Ein Quicksort entsprechend den Forderungen
    * von Aufgabe 52: Quicksort mit Wahl des ersten Element als Anker,
    * die zu tauschenden Objekte verden in while schleifen ermittelt.
    * (im Intervall left0+1 - right0)
    * Veraenderungen gegenueber der oesung mit anker in der mitte
    * (wirth0, wirth1) gekennzeichnet mit **
    * <br>
    * @param a das zu sortierende DocumentDataArray
    * @param left0 der startwert links
    * @param right0 der startwert von rechts
    */
    ////////////////////////////////////////////////////////////////////
    
    static void quicksort52Do(DocumentData[] a, int left0, int right0) {
    int left, right;
    DocumentData x, temp;
    int l = a.length; // fuer den abbruch aus der while schleife
    
    left = left0; right = right0+1;/****/
    x = a[left0];
        
    do { // arbeitet das restliche Intervall schrittweise ab
    
        do { left++; if(left >= l) break;} while ( a[left].getRank() > x.getRank() ); /****/
        // sucht einen groesseren Wert als x von links
        do right--; while ( a[right].getRank() < x.getRank() ); /****/
        // sucht einen kleineren Wert als x von rechts
        
        if ( left < right ) { /****/  // Paartausch, nicht wenn identisch
            temp = a[left]; a[left] = a[right]; a[right] = temp;
            /****/ //hier folgendes nicht mehr noetig: left++; right--;
        }
    }
    while ( left <= right );// bis Intervall leer ist
    temp = a[left0]; a[left0] = a[right]; a[right] = temp;
    //das kleinste an den anfang kopieren
    
    // neue Intervalle: wie gehabt
    if ( left0 < right )  quicksort52Do(a, left0, right);
    if ( left < right0 )  quicksort52Do(a, left, right0);
    }
}

