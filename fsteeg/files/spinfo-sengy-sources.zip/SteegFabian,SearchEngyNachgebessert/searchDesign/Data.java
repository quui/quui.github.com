package searchDesign;

/**
*
* <p>Beschreibung: Data ist die abstrakte Basisklasse, auf der die
* spezialisierten Datentypen KeyData und DocumentData aufbauen,
* da beide in den gleichen Speicherstrukturen untergebracht
* werden sollen. </p>
* @version 1.0
*/

public abstract class Data implements java.io.Serializable{

  /**
    * getKey() gibt den Schl�ssel des jeweiligen Objektes zur�ck, bei KeyData
    * ist dies das Schl�sselwort als String, bei DocumentData die ID als
    * Integer-Objekt.
    *
    * @return key - der Schl�ssel des Objektes
    */

 public abstract Object getKey();

 /**
  * Vergleichsfunktion, die einen Schl�ssel "other" erwartet,
  * also einen String bei KeyData- und einen Integer bei DocumentData-Objekten,
  * und durch den R�ckgabewert anzeigt, ob dieser kleiner (<0), gr��er (>0) oder
  * gleich(==0) dem gespeicherten Schl�ssel ist.
  *
  * @param other Der Schl�ssel, mit dem verglichen wird
  * @return das Ergebnis des Vergleichs
  */
 public abstract int compareTo(Object other);

 /**
  * add wird beim Einf�gen eines Data-Objektes in eine Direktzugriffsstruktur
  * benutzt, wenn in dieser bereits ein Objekt mit gleichem Schl�ssel
  * gespeichert ist. Falls es sich bei other um ein KeyData handelt,
  * werden die DocumentData akkumuliert. Falls es sich um ein DocumentData
  * handelt, werden die Positionen und Spaces akkumuliert.
  *
  * @param other das Objekt, das hinzugefuegt werden soll
  */
 public abstract void add(Object other);


}