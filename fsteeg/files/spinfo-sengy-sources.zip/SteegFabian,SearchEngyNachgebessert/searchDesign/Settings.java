package searchDesign;

/**
 *
 * <p>Description: Diese Klasse stellt UserData(Einstellungen) global zur
 * Verf�gung.</p>
 * @version 1.0
 */

public class Settings {

    public static UserData user;

}