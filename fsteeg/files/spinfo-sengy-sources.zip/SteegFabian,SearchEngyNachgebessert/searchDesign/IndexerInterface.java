package searchDesign;

import java.io.*;

/**
 *
 * <p>Beschreibung:
 * Verwaltet die Nichtstopw�rter mit dem Wort als Key und einer Instanz
 * von KeyData als zugeh�rigem Wert. Intern wird ein Hashtable oder ein
 * sortierter Bin�rbaum benutzt.</p>
 * @version 1.0
 */
public interface IndexerInterface {

  /**
   * Funktion, die zur Initialisierung von Klassen, welche
   * dieses Interface implementieren, aufgerufen werden mu�.
   * @param useTable wenn true, wird zur internen Verwaltung der KeyData-Objekte
   * eine Hashtable benutzt. Bei false entsprechend ein Bin�rbaum.
   */

    public void initialize (int struktur);

    /**
     * F�gt KeyData-Objekt newWord in die interne Direktzugriffsstruktur ein
     * mit dem Wort als Key und dem KeyData als zugeh�rigem Wert,
     * falls der Key nicht bereits enthalten ist. Andernfalls werden die in newWord
     * enthaltenen DocumentData mit denen des bereits gespeicherten KeyData 
     * akkumuliert, d.h. ihnen hinzugef�gt.
     *
     * @param newWord Das neue KeyData-Objekt
     */

    public void put(Data newWord);

    /**
     * Speichert die interne Direktzugriffsstruktur in einer Datei.
     * @param fileName der Name der Datei, in die geschrieben werden soll
     * @throws java.io.IOException Falls w�hrend des Speichervorgangs ein Fehler auftritt.
     */
    public void saveBinary(String fileName) throws java.io.IOException;
}