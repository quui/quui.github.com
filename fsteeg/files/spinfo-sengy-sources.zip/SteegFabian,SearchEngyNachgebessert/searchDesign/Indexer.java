package searchDesign;

import java.io.*;
import java.util.Vector;
import java.util.Enumeration;

//////////////////////////////////////////////////////////////////////////////////////////////////
/**
* <p>Beschreibung: Der Indexer Verwaltet die Nichtstopw�rter mit dem Wort als Key und einer Instanz
* von KeyData als zugeh�rigem Wert. Intern wird ein Hashtable, ein ausgewogener
* sortierter Binaerbaum, abgeleitet von java.util.TreeMap oder ein einfacher, selbst 
* implementierter sortierter Bin�rbaum  benutzt.</p>
* @author Fabian Steeg
*/
//////////////////////////////////////////////////////////////////////////////////////////////////

public class Indexer implements IndexerInterface {
    
    private StorageInterface index;
    private Vector pfade = new Vector(20,5);
    
    //   zur Instanziierung der Hashtable
    private long vermuteteWorte;
    
    //////////////////////////////////////////////////////////////////
    /**
    * Funktion, die zur Initialisierung aufgerufen werden mu�.
    * @param struktur ein int, das bestimmt welche Datenstruktur
    * zur internen Verwaltung der KeyData-Objekte benutzt wird.
    * bei 0 ein einfacher Baum, bei eins der von TreeMap abgeleitete,
    * bei 2 eine Hashtable
    */
    //////////////////////////////////////////////////////////////////
   
    public void initialize (int struktur){
        
        if(struktur == 0) {
            index = new StorageTree();
            Settings.user.talk.message("gewaehlte Datenstruktur: sortierter Binaerbaum, eigene Implementation.");
            
        }
        
         else if (struktur == 1){
            index = new StorageTreeMap();
            Settings.user.talk.message("gewaehlte Datenstruktur: sortierter und ausgewogener Binaerbaum, (extends java.util.TreeMap)");
            
        }
        
        else{ 
            Settings.user.talk.message("gewaehlte Datenstruktur: Hashtable (java.util.Hashtable, leicht mod.)");
        
            try{
                
            //   nun zunaechst ermittlung der geschaetzten benoetigten groesse
            
            LineNumberReader ini; //   Zum zeilenweisen Einlesen der Datei "docmap.txt"
            ini = new LineNumberReader(new BufferedReader(new FileReader(Engine.docMapFile)));
            pfade = new Vector(20,5);
            String in;
            ini.readLine(); //   die Zeile mit der Dok - Zahl ueberlesen
            while ((in = ini.readLine()) != null){
                pfade.add(in);      
                ini.readLine(); //   die Zeile mit der Wortzahl ueberlesen
            }
            
            //   ermittlung der Summe aller Laengen aller Dateien
            Enumeration e = pfade.elements();
            long alleDateiLaengen = 0;
            while (e.hasMoreElements()){
                File eine = new File((String)e.nextElement());
                alleDateiLaengen = alleDateiLaengen+eine.length();
            }
            long gesamtVermuteteZeichen = alleDateiLaengen / 5;
            vermuteteWorte = gesamtVermuteteZeichen / 10;
            //   in Laufzeitvergleiche gute Ergebnisse mit einer angenommenen
            //   Wortlaenge von 10
            
            index = new StorageTable((int)(vermuteteWorte * 125.E-2F), 8E-1F);
            
            }
            
            catch(Throwable erx){
                Settings.user.talk.error("Fehler beim Lesen der DokMap Datei zum Ermitteln der Anfangsgroesse des StorageTables:\n" + erx  + "\nGenaueres finden Sie in der Programmausgabe");
                erx.printStackTrace();
            }
        }
        
       
    }
    
    /////////////////////////////////////////////////////////////////////////////
    /**
    * F�gt KeyData-Objekt newWord in die interne Direktzugriffsstruktur ein
    * mit dem Wort als Key und dem KeyData als zugeh�rigem Wert,
    * falls der Key nicht bereits enthalten ist. Andernfalls werden die in newWord
    * enthaltenen DocumentData mit denen des bereits gespeicherten KeyData 
    * akkumuliert, d.h. ihnen hinzugef�gt.
    *
    * @param newWord Das neue KeyData-Objekt
    */
    //////////////////////////////////////////////////////////////////////////////
    
    public void put (Data newWord){
        index.put(newWord);
    }
    
    ////////////////////////////////////////////////////////////////////////////////////
    /**
    * Speichert die interne Direktzugriffsstruktur in einer Datei.
    * @param fileName der Name der Datei, in die geschrieben werden soll
    * @throws java.io.IOException Falls w�hrend des Speichervorgangs ein Fehler auftritt.
    */
    ////////////////////////////////////////////////////////////////////////////////////
    
    public void saveBinary (String fileName) throws java.io.IOException {
        FileOutputStream outFile = new FileOutputStream(fileName);
        ObjectOutputStream sOut = new ObjectOutputStream(outFile);
        sOut.writeObject(index);
        Settings.user.talk.message("'Index' - Datei geschrieben (serialisiert).");
        
    }
}