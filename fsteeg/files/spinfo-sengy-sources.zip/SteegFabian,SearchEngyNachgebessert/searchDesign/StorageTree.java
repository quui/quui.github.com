package searchDesign;

import java.io.*;

///////////////////////////////////////////////////////////////////
/**<p>
* eine moegliche Datenstruktur: ein einfacher sortierter binaerbaum
* </p>
* @author Fabian Steeg
*/
///////////////////////////////////////////////////////////////////

public class StorageTree implements StorageInterface, java.io.Serializable{
    
    /*   geschuetzter Knoten und get-Methode   */
    
    private Node root;
    
    public Node getRoot(){
        return this.root;
    }
   
    /*   groesse, fuer asDataArray benoetigt   */
   
    private int size = 0;
   
    /*   Konstruktoren:  */
    
    public StorageTree(){}
    
    /*   ----------  put(...) und benuzte Funktionen   */
    
    /////////////////////////////////////////////////////////////////////
    /*
    * Fuegt newData in die Direktzugriffsstruktur ein. Falls der Key von
    * newData bereits darin enthalten ist, wird die Methode add von
    * Data aufgerufen.
    *
    * @param newData Das neu einzufuegende Data-Objekt
    */
    /////////////////////////////////////////////////////////////////////
    
    public void put(Data newData){
        
        //   erstes put()?
        if(this.root==null && newData!=null){
            this.root = new Node(newData);
            this.size++;
        }
        //   Einzufuegendes hat Wert?
        else if (newData != null){
            //   rekursive Funktion aktivieren
            this.root = insert(this.root, newData);
        }
    }
    
    ///////////////////////////////////////////////////////
    /**
    * die rekursive einfuege - methode
    * @param root der knoten, ab dem eingefuegt werden soll
    * @param neuerWert das einzufuegende Data - Objekt
    * @return root incl des eingefuegten neuen Data
    */
    ///////////////////////////////////////////////////////
    
    //   die rekursive Einfuege - Funktion
    private Node insert(Node root, Data neuerWert) {
        
        //   hier verwende ich den Kopier-Konstruktor,
        //   da ich einen identischen, aber neuen Knoten will.
        
        Node ergebnis = new Node(root);
        
        int vergleich = (  (Data) ergebnis.wert  ).compareTo(  neuerWert.getKey()  );
        
        if(vergleich == 0){//   neuer wert bereits da
            (  (Data) ergebnis.wert  ).add(neuerWert);
            return ergebnis;
        }   
        
        if ( vergleich > 0) { //   neuer muss nach links
        
            if (ergebnis.links != null) {  //    solange links besetzt
                ergebnis.links = insert(ergebnis.links, neuerWert); //   links einfuegestelle suchen
            }
                
            else {
                ergebnis.links = new Node(neuerWert);//   einfuegen.
                this.size++;
            }
        }
        
        else if (vergleich < 0) {//   neuer muss nach rechts
            if (ergebnis.rechts != null){
                ergebnis.rechts = insert(ergebnis.rechts, neuerWert);
            }
            else {
                ergebnis.rechts = new Node(neuerWert);
                this.size++;
            }
        }
        
        return ergebnis;
    }
    
   
    /* ----------  get(...) und benutzte Funtionen  */
    
    /////////////////////////////////////////////////////////////////
    /**
    * Gibt den Wert von key zurueck, oder null, wenn key nicht in der
    * Direktzugriffsstruktur enthalten ist
    *
    * @param key Der Schluessel, dessen Wert gesucht wird
    * @return Der Wert des gefundenen Schluessels
    */
    ////////////////////////////////////////////////////////////////
    
    public Object get (Object key){
        if (this.root == null)
            return null;
        else
            return find(this.root, key);
    }
    
    //////////////////////////////////////////////////////
    /**
    * Suchfunktion zum Suchen eines Wertes in einem Knoten
    *
    * @param node der knoten ab dem gesucht werden soll
    * @param searchValue der zu suchende Wert, ein Object
    * @return das gefundene Object, (Data) Object
    */
    //////////////////////////////////////////////////////
    
    private Object find(Node node, Object searchValue) {
        // rekursive Version. 
        int compareResult;
        Object result = null;
        Data tempD = (Data) node.wert;
        
        if ( (compareResult = tempD.compareTo(searchValue)) == 0){
            return node.wert;
        }
        else if ( compareResult > 0 ) {
            if (node.links != null)
                return find(node.links, searchValue);
        }
        else { //   compareResult < 0
            if (node.rechts != null) 
                return find(node.rechts, searchValue);
        }
        return result;
    }
    
    
    /* ---------- asDataArray(...) und benuzte Funktion */
    
    ////////////////////////////////////////////////////////////////////
    /**
    * Erzeugt aus der Datenstruktur ein Array mit Data-Objekten und gibt
    * dieses zurueck.
    *
    * @return Data-Array
    */
    ////////////////////////////////////////////////////////////////////

    public Data[] asDataArray(){
        i = 0;
        Data[] ergebnis = new Data[this.size];
        if(this.root!=null)
            baumAufArray(this.root, ergebnis);
        return ergebnis;
    }
    
    private int i; 
    
    ////////////////////////////////////////////////////////////////////
    /**
    * Preorder Traversal ueber Baum, dabei Werte des Baums auf ein Data[]
    * @param node der zu traversierende Knoten
    * @param ziel das Data[], das bestueckt werden soll
    */
    ////////////////////////////////////////////////////////////////////
    
    private void baumAufArray(Node node, Data [] ziel) {
        // preorder traversal
        
        if (node.links != null)
            baumAufArray(node.links, ziel);
            
        //if(node.wert != null)    
            ziel[i] = (Data) node.wert; 
        if(i==ziel.length-1)
            return;
        i++;
        
        if (node.rechts != null)
            baumAufArray(node.rechts, ziel);
        return;
    }
    
    /* ---------- size() */
    
    /////////////////////////////////////////////////
    /**
    * gibt die Anzahl der gespeicherten Keys zurueck
    * this.size wurde immer beim einfuegen eines neuen 
    * knotens hochgezaehlt.
    * @return die Anzahl der gespeicherten Keys
    */
    //////////////////////////////////////////////////
    
    public int size () {
        return this.size;
    }
}