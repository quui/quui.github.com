package searchDesign;

//////////////////////////////////////////////////////////////////////////////
/**
 * <p> Beschreibung:  
 * Ein KeyData speichert ein Schl�sselwort und eine Direktzugriffsstruktur mit
 * DocumentData-Objekten, die jeweils die Fundstellen des Schl�sselwortes
 * in einem Text enthalten. </p>
 * @author Fabian Steeg
*/
//////////////////////////////////////////////////////////////////////////////

public class KeyData extends Data implements KeyDataInterface, java.io.Serializable{
    
    /* Konstruktor */
    
    public KeyData(){}//this.dokumente = new StorageTree();}
    
    /* Attribute */
    
    private String wort; private StorageInterface dokumente;
    
    /* Funktionen */
    
    ////////////////////////////////////////////////////////////////////////////////////
    /** 
    * Funktion, die aufgerufen werden muss, wenn ein KeyData initialisiert werden soll.
    * In dieser Funktion muss anhand der Informationen aus Settings.user
    * entschieden werden, ob die DocumentData in einer Hashtable oder in
    * einem Bin�rbaum gespeichert werden
    *
    * @param key Schl�sselwort
    * @param position Byte-Position des ersten Buchstaben von key im Text
    *
    * @param space Anzahl der Nichtwortzeichen (inkl. HTML-Tags) zwischen key und dem
    * vorigen Wort (unabh�ngig davon, ob letzteres ein Stopwort ist oder nicht)
    * im Text
    *
    * @param docID vom Parser verwaltete ID des aktuellen Dokuments, die auch
    * in der docmap-Datei gespeichert wird
    */
    ////////////////////////////////////////////////////////////////////////////////////
    
    public void initialize(String key, int position, short space, int documentID){
        this.wort=key;
        DocumentData tempDocData = new DocumentData();
        tempDocData.initialize (documentID,position,space);
        if(Settings.user.interneDatenstrukturKeyData == 1)
            this.dokumente = new StorageTable();
        else if(Settings.user.interneDatenstrukturKeyData == 0)
            this.dokumente = new StorageTree();
        else
            this.dokumente = new StorageTreeMap();
            
        this.dokumente.put(tempDocData);
    }
    
    ///////////////////////////////////////////////////////////////////////////
    /**
    * gibt die Direktzugriffsstruktur als StorageInterface zur�ck, welche alle
    * DocumentData von KeyData enth�lt
    *
    * @return das StorageInterface mit den entsprechenden DocumentData-Objekten
    */
    ///////////////////////////////////////////////////////////////////////////
    
    public StorageInterface getDocuments(){
        StorageInterface raus = dokumente;
        return raus;
    }
    //////////////////////////////////////////////////////////////////
    /**
    * getKey() gibt den Schl�ssel des jeweiligen Objektes zur�ck, hier
    *  das Schl�sselwort als String, 
    *
    * @return key - der Schl�ssel des Objektes, hier das Wort
    */
    //////////////////////////////////////////////////////////////////
    
    public Object getKey(){
        Object raus = this.wort;
        return raus;
    }
    
    //////////////////////////////////////////////////////////////////
    /**
    * Vergleichsfunktion, die einen Schl�ssel "other" erwartet,
    * hier einen String, und durch den R�ckgabewert anzeigt, 
    * ob dieser kleiner (<0), gr��er (>0) oder
    * gleich(==0) dem gespeicherten Schl�ssel ist.
    *
    * @param other Der Schl�ssel, mit dem verglichen wird, hier String
    *
    * @return das Ergebnis des Vergleichs
    */
    /////////////////////////////////////////////////////////////////
    
    public int compareTo(Object other){
        String temp = (String) other;
        int result = this.wort.compareTo(temp);
        return result;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    /**
    * add wird beim Einf�gen eines Data-Objektes in eine Direktzugriffsstruktur
    * benutzt, wenn in dieser bereits ein Objekt mit gleichem Schl�ssel
    * gespeichert ist. Hier werden die DocumentData akkumuliert. 
    *
    * @param other das Objekt, das hinzugefuegt werden soll, ein KeyData
    */
    ///////////////////////////////////////////////////////////////////////////
    
    public void add(Object other){
         KeyData in =  (KeyData)other;
        Data [] quelle = in.dokumente.asDataArray();
        this.dokumente.put(quelle[0]);
    }
    
    private void addFrom(Data [] in){
        int l = in.length;
        for (int i = 0; i<l; i++)
            this.dokumente.put(in[i]);
    }
        
}