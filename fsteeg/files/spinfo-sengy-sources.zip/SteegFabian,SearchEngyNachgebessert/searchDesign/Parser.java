package searchDesign;

import java.io.*;
import java.util.Hashtable;

/////////////////////////////////////////////////////////////////////////////
/**
* <p>Beschreibung: Der Parser wird �ber die Methode initialize mit einer
* Stopwort-Datei und einem Crawler initialisiert. Er bearbeitet
* sequentiell alle Dateien, die der Crawler ihm zur Verf�gung stellt
* mit seiner Methode nextWord. Die Methode nextWord, die die nextWord()
* des benoetigten Filters aufruft gibt erst null zur�ck,
* wenn das letzte Wort der letzten Datei abgearbeitet wurde. Nachdem er alle
* Dateien abgearbeitet hat, erzeugt der Parser eine docMap-Datei
* (Methode writeDocMap, s.u.) und schreibt die Pfade der bearbeiteten Dateien,
* jeweils gefolgt (in einer neuen Zeile) von der Anzahl der eingelesenen
* Nichtstopw�rter.</p>
* @author Fabian Steeg
*/
//////////////////////////////////////////////////////////////////////////////

public class Parser implements ParserInterface {
    
    // _____________________________________________    Attribute
      
    /*   zum Einlesen der Halteworte   */
    private Hashtable halteWorte; 
    private String[] pfade;
    private Zeichenfilter filter;
      
    /*   zum Erkennen ob ein neues Dokument begonnen wurde   */
    private boolean istErstes;
      
    /*   zum Weiterschalten ueber die Dokumente   */
    private int aktDok;
      
    /*   zum Zaehlen der suchrelevanten Worte   */
    private int nichtHalteWorte;
      
    //   kleines array zum zaehlen der wortanzahl
    //   der einzelnen Dokumente
    private int [] wortzahlInDok; 
      
    // _____________________________________________    Funktionen
      
    ///////////////////////////////////////////////////////////////////////////  
    /**
    * Initialisierungsmethode
    * Liest die Stopwords datei ein und traegt sie auf eine Hashtable ein
    * @param stopWordFileName Der Pfad zu der Datei, die die Stopw�rter enth�lt
    * @param crawler Der zuvor erzeugte Crawler
    *
    * @throws java.io.FileNotFoundException
    * @throws java.io.IOException
    */
    ///////////////////////////////////////////////////////////////////////////
   
    public void initialize (String stopWordFileName, CrawlerInterface crawler)
    throws java.io.FileNotFoundException, java.io.IOException {
        
        // die nicht - suchrelevanten Woerter lesen
        
        File halteWorteDatei = new File(stopWordFileName);
        Zeichenfilter halteEin = new Textfilter(halteWorteDatei);
        
        String halteWort = new String(); // vormals: char[] word;
        halteWorte = new Hashtable(); 
         // *********************  hier wird gelesen   ***********
        while (  (halteWort = halteEin.nextWord(false)) != null ) {
            if (halteWort != "")
                halteWorte.put(halteWort.toUpperCase(), halteWort.toUpperCase());
        }//*******************************************************
        Settings.user.talk.message("'Stopword' - Liste eingelesen.");
        
        //   die Pfade zu den Dateien holen 
        this.pfade = crawler.getFiles();
        
        //   da initialisierung sonst nur in der Engine.init
        Engine.crawler = new Crawler();
        //  das Wortezaehl - Array initialisieren
        wortzahlInDok = new int[pfade.length];
        
        // Zaehler und Flag auf Anfang
        this.istErstes = true;
        nichtHalteWorte = 0;
    }
    
    ////////////////////////////////////////////////////////////////////////////////////
    /**
    * liefert jeweils ein Wort zur�ck, in Form eines KeyData.
    * Der Parser ber�cksichtigt nur Nichtstopw�rter, d.h. Stopw�rter
    * werden �berlesen. Bei Nichtstopw�rtern gibt der Parser ein KeyData zur�ck.
    * Ein KeyData enth�lt: <br>
    * - den eingelesenen String als key (klein geschrieben), <br>
    * - die Anfangsposition des Wortes, <br>
    * - den Abstand zwischen dem vorigen und dem eingelesen Wort im Text, d.h. die Anzahl
    *   der Nichtwortzeichen zwischen den beiden W�rtern, <br>
    * - die ID (int) des Dokuments, in dem das Wort enthalten ist. <br>
    * Es wird immer der Abstand zum tats�chlichen vorigen Wort im Text gespeichert,
    * unabh�ngig davon, ob dieses ein Stopwort ist oder nicht.
    *
    * @return ein Keydata-Objekt mit oben beschriebenem Inhalt oder null
    * @throws java.io.IOException
    * @throws java.io.FileNotFoundException
    */
    ////////////////////////////////////////////////////////////////////////////////////
     
    
    public Data nextWord() throws java.io.IOException, java.io.FileNotFoundException{
        //   Aufruf eine Funktion, die mit einem Array aufgerufen wird
        if(pfade.length == 0)
            return null;
        
        return nextWord(pfade);
    }
    
    ////////////////////////////////////////////////////////////////////////////////////
    /**
    *@param pfade das vom Crawler gelieferte array
    */
    ////////////////////////////////////////////////////////////////////////////////////
     
    private Data nextWord(String [] pfade) throws java.io.IOException, java.io.FileNotFoundException{
        
        int dokumentAnzahl = pfade.length;
        String pfadZuAktDok = pfade[aktDok];
     
        //   das Ergebnis
        KeyData eintrag = new KeyData();
        
        if(this.istErstes){ //   nur wenn neues Dokument begonnen wurde neuen Filter erzeuegen
        
            String tempString = pfadZuAktDok.substring(pfadZuAktDok.length() - 4).toUpperCase();
            
            //   Teilstring bilden zur Ermittlung der Endung 
                    
            if (tempString.compareTo(".TXT")==0){
                this.filter = new Textfilter(  new File(pfadZuAktDok)  );
            }
            
            else if(tempString.compareTo(".HTM")==0 || tempString.compareTo("HTML")==0){
                this.filter = new Hypertextfilter(new File(pfadZuAktDok));
                ((Hypertextfilter)filter).initialize("HTMLCodes.txt");
            }
            
            Settings.user.talk.message("....................................................................................");
            
            Settings.user.talk.message(aktDok+1 +". " + pfadZuAktDok);
        }
        
        //   aktuelle Position in der Eingabe vor dem Lesen ermitteln
        int posNachLeWort = this.filter.aktuellePosition();  //- this.filter.laeLeWort();
        
        //   daraus und aus der Laenge des vorigen Worte Beginn des
        //   naechsten ermitteln
        
        //   nun das naechste Wort lesen
        String wortFuerData = this.filter.nextWord(false);
        
        int posFuerData = this.filter.aktuellePosition() - this.filter.laeLeWort();
        
        //   daraus wiederum den Abstand des zu lesendem zum vorigen bestimmen
        int absFuerData =  posFuerData - posNachLeWort;
        
        //   und flag aendern
        this.istErstes = false;
        
        //   wenn das Wort null ist...
        if(wortFuerData == null) {
            //   koennen alle Dokumente...
            if( aktDok >= dokumentAnzahl-1) {
                wortzahlInDok[aktDok] = nichtHalteWorte;
                Settings.user.talk.message(new Integer(nichtHalteWorte).toString() + " suchrelevante Worte gefunden.");
                int alleWoerter = 0;
                for (int j=0;j<wortzahlInDok.length;j++)
                    alleWoerter = alleWoerter + wortzahlInDok[j];
                Settings.user.talk.message("");
                Settings.user.talk.message("....................................................................................");
                
                Settings.user.talk.message(alleWoerter + " suchrelevante Worte insgesamt gefunden.");
                
                writeDocMap(Engine.docMapFile);
                this.aktDok = 0;
                return null;
            }
            //   oder nur ein Dokument abgearbeitet sein.
            else{
                //   in diesem Fall speichere ich die gezaehlten Worte. 
                wortzahlInDok[aktDok] = nichtHalteWorte;
                //   flag und Zaehler wieder auf Anfang
                this.istErstes = true;
                
                Settings.user.talk.message(new Integer(nichtHalteWorte).toString()  + " suchrelevante Worte gefunden.");
                
                nichtHalteWorte = 0;
                //   Dokumentenzaehler weiterschalten
                aktDok++;
                //   naechstes Wort zurueckgeben (rekursiver Aufruf)
                return nextWord(pfade);
            }
       }
       
       //   pruefen, ob es sich um ein fuer die Suche relevantes Wort handelt:
       if(  halteWorte.contains(wortFuerData.toUpperCase()) == false  )
            eintrag.initialize(wortFuerData.toUpperCase(), posFuerData, (  (short) absFuerData  ), aktDok);
       else
            return nextWord(pfade);
            
       //   vor der Rueckgabe eines gueltigen Eintrages hochzaehlen
       nichtHalteWorte++;
       
       return eintrag;
        
    }   
    
    //////////////////////////////////////////////////////////////////////////////
    /**
    * schreibt in der DocMap-Datei mit Namen fileName folgende Informationen: <br>
    * - in der ersten Zeile: die Anzahl der bearbeiteten Dateien <br>
    * - danach jeweils den Pfad zu einer bearbeiteten Datei, gefolgt in einer
    * eigenen Zeile von der Anzahl der in der betroffenen Datei eingelesenen
    * Nichtstopw�rter.<br>
    * Die DocMap-Datei enth�lt keine Leerzeilen
    * @param fileName Der Pfad zur DocMap-Datei
    */
    //////////////////////////////////////////////////////////////////////////////
    
    public void writeDocMap(String fileName){
        try{
            
        //   anlegen der datei    
        FileOutputStream rausFile = new FileOutputStream(fileName);
        int anzDok = this.pfade.length;
        
        //   schreibe Anzahl der Doks
        Integer anzahlDoks = new Integer(anzDok);
        String dokZahl = anzahlDoks.toString();
            
        int f = dokZahl.length();
        for (int k = 0; k < f; k++){
            rausFile.write( dokZahl.charAt(k) );
        }
        
        //   schreibe Zeilenumbruch
        rausFile.write(13);
        rausFile.write(10);
        
        //   ueber saemtliche Pfade
        for(int i=0; i<pfade.length;i++){ 
            
            // schreibe Pfad
            int l = pfade[i].length();
            for (int j = 0; j < l; j++){
                rausFile.write(  pfade[i].charAt(j)  );
            }
            
            // schreibe Zeilenumbruch
            rausFile.write(13);
            rausFile.write(10);
            
            // schreibe Anzahl der Worte
            Integer anzahl = new Integer(wortzahlInDok[i]);
            String worteZahl = anzahl.toString();
            
            int l2 = worteZahl.length();
            for (int k = 0; k < l2; k++){
                rausFile.write( worteZahl.charAt(k) );
            }
            
            // schreibe Zeilenumbruch
            rausFile.write(13);
            rausFile.write(10);
            
        }
           
        rausFile.close();
        
        }
        catch (Throwable erx) { // Error or Exception
           Settings.user.talk.error("Fehler beim Schreiben der 'DocMap' - Datei im Parser:\n" + erx  + "\nGenaueres finden Sie in der Programmausgabe");
           erx.printStackTrace();
        }
    }
}