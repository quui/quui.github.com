package searchDesign;
/**
 *
 * <p>Beschreibung: Dient zur Kommunikation mit dem User. Wird in UserData
 * benutzt,  um eine globale I/O-Schnittstelle zur Verf�gung zu stellen. </p>
 * @version 1.0
 */

public interface TalkInterface {

/**
 * Wird ben�tigt, um Informationen des Benutzers anzufordern. Die Antwort auf
 * die als Parameter �bergebene Frage wird als String zur�ckgegeben.
 *
 * @param question Die Frage
 * @return Die gegebene Antwort
 */
 public String question(String question);

 /**
  * Gibt eine Information an den Benutzer weiter.
  *
  * @param info Die Information
  */
 public void message(String info);

 /**
  * Wie message, zus�tzlich wird die Information als Fehler deklariert.
  *
  * @param warning Die Fehlerbeschreibung
  */
 public void error(String warning);
}