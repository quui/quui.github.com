package searchDesign;

import java.io.*;

/**
 *
 * <p>Beschreibung: </p>
 * ConsoleTalk implementiert genau wie GuiPrintStream das Interface TalkInterface,
 * um die Kommunikation zwischen Benutzer und Programm zu steuern. In dieser Klasse
 * (die von SearchEngy lediglich vor dem Laden der GUI in der Main benutzt wird) 
 * werden die Ein- und Ausgaben auf die Konsole umgelenkt.
 * @version 1.0
 */
public class ConsoleTalk implements TalkInterface {
   private static PrintWriter out;
   private static BufferedReader in;

 public ConsoleTalk() {
    try {
     out = new PrintWriter(new OutputStreamWriter(System.out, "Cp437"));
     in = new LineNumberReader(new BufferedReader(new InputStreamReader(System.in, "Cp437")));
    } catch (java.io.IOException x) {
     System.out.println("ConsoleTalk:\n" + x);
    }
 }

 public String question(String question) {
    try {
        out.println(question);
        out.print(">");
        out.flush();
        String toReturn = in.readLine();
        return ""+toReturn;
    } catch (java.io.IOException x) {
     System.out.println("ConsoleTalk:\n" + x);
     return null;
    }
 }
 
 public void message(String info) {
  out.println(info);
  out.flush();
 }
 
 public void error(String warning) {
  out.println("Ein Fehler ist aufgetreten:");
  out.println(warning);
  out.flush();
 }

}