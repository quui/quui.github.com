package searchDesign;

////////////////////////////////////////////////////////////////////////////
/**
* <p> Node ist der Knoten eines StorageTrees. Er speichert ein Object value,
* die Nodes left und right </p>
* @author Fabian Steeg
*/
////////////////////////////////////////////////////////////////////////////

public class Node implements java.io.Serializable {
    
    /*   Standard Attribute eines Baumes: left, right, value   */
    public Node links;
    public Node rechts;
    public Object wert;
    
    /*   default knonstruktor   */
    Node(){}
    
    /*   Konstruktor zum bestuecken eines leeren Knotens mit einem value   */
    Node(Data in) {
        this.wert = in;
    }
    
    /*   Konstruktor zum erzeuegn einer Kopie eines Knotens (mit left und right, 
    d.h. einens Baums oder Teilbaums)   */
    Node(Node zuVerdoppeln) {
        this.links = zuVerdoppeln.links;
        this.rechts = zuVerdoppeln.rechts;
        this.wert = zuVerdoppeln.wert;
    }
    
}
