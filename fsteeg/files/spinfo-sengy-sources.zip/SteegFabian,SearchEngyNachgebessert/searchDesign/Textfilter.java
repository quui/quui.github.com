package searchDesign;
import java.io.*;

//////////////////////////////////////////////////////////////////////////////
/** 
* <p> Beschreibung: Ein Filter zum Lesen aus einer Textdatei
* Er verfuegt in seiner nextWord(), die das naechste Wort der Eingabe
* liefert ueber eine Option,ob Satzzeichen (.,:;?!) ueberlesen oder mitgelesen 
* werden.
* </p>
* @author Fabian Steeg
*/  
//////////////////////////////////////////////////////////////////////////////

class Textfilter extends Zeichenfilter { 
                                              
    /* Attribute */
    
    private BufferedReader reader;
    private int chValue;
    private int aktuellesDokument;
    private int aktuellePosition;
    private int firstOfLast;
    private Buffer buffer;
    
    /* Konstruktoren */
    
    Textfilter () throws IOException{
        this.aktuellePosition = 0;
        this.buffer = new Buffer();
    }
    Textfilter (BufferedReader rd) throws IOException{
        this.reader = rd;
        this.aktuellePosition = 0;
        this.buffer = new Buffer();
        
    } 
    Textfilter (Reader rd) throws IOException{
        this.reader = new BufferedReader(rd);
        this.aktuellePosition = 0;
        this.buffer = new Buffer();
        
    } 
    Textfilter (File f) throws IOException{
        this.reader = (new BufferedReader(new FileReader(f)));
        this.aktuellePosition = 0;
        this.buffer = new Buffer();
        
    }
    
    /*   Funktionen zum Ermitteln der notwendigen Informationen   */
    
    ///////////////////////////////////////////////////
    /**
    * Laenge des vorigen Wortes bestimmen
    * @return  ein short, die Laenge des vorigen Wortes
    */
    ///////////////////////////////////////////////////
    
    public short laeLeWort(){
        return (short) (this.aktuellePosition - this.firstOfLast);
    }
    
    ////////////////////////////////////////////////////////
    /**
    * Aktuelle Position in der Eingabe bestimmen
    * @return  ein int, die aktuelle Position in der Eingabe
    */
    ////////////////////////////////////////////////////////
    
    public int aktuellePosition(){
        return this.aktuellePosition;
    }
    
    ////////////////////////////////////////////////////////
    /**
    * nextWord()
    * Liest das naechste Wort vom Eingabestrom in und gibt 
    * es nach Zwischenspeicherung in einem Buffer als String 
    * zurueck.
    * 
    * @return  ein String, das naechste Wort der Eingabe
    * oder null wenn er am Ende angelangt ist
    */
    ////////////////////////////////////////////////////////
    
    //   die nextWord() wird in ihrer grundfunktionalitaet von allen Filtern
    //   verwendet, denkbar waere daher eine Klasse zu schreiben, deren 
    //   Instanzen diesen grundlegende Lesevorgang ausfuehren und die von
    //   den Filtern implementiert wuerde oder aber den Vorgang in der ver-
    //   erbenden Klasse auszufuehren...
    
    public String nextWord(boolean satzZeichenMitlesen) throws IOException {

		boolean leseBedingung;
		
		//   Zeichen ueberlesen bis zum ersten Buchstaben
        while ( chValue != -1 && !isLetter(chValue) && !isGermanLetter(chValue)  ){
            
            	chValue = reader.read();
            	this.aktuellePosition++;
            	
        }
        if (chValue == -1)
           	return null;

        this.buffer.reset();//Buffer buffer = new Buffer();
        
        // ein Buffer.reset, 
        // welches den Buffer fuer eine erneute Benutzung zurecksetzt,
        // so kommt man mit nur einem Buffer-Objekt aus.
        
        this.firstOfLast = this.aktuellePosition;
        
        do {
            	buffer.append((char)chValue);
            	chValue = reader.read(); //
            	this.aktuellePosition++;
            	if(satzZeichenMitlesen)
                    leseBedingung = (isLetter(chValue) || isGermanLetter(chValue) || istSatzZeichen(chValue));
                else
                    leseBedingung = (isLetter(chValue) || isGermanLetter(chValue));
        }
        
        //   Bedingung zum Weiterlaufen ueber Stream: ist ein Buchstabe
       	while ( leseBedingung );
        return buffer.toString();
    } // -------------------------------------------------- funkt. ende
    
    ///////////////////////////////////////////////////////
    /**
    * isLetter()
    @param chValue das aktuelle Zeichen der Eingabe als int
    @return ob das Zeichen ein Buchstabe des Englischen ist
    */
    ///////////////////////////////////////////////////////
    
  	private boolean isLetter(int chValue){
  	    if (chValue != -1   &&   chValue >= 65 && chValue <= 90 && chValue != -1  || chValue >=97 && chValue <= 122 && chValue != -1   )
  	    return true;
  	    else return false;
  	}
  	
  	///////////////////////////////////////////////////////
  	/**
    * isGermanLetter()
    @param chValue das aktuelle Zeichen der Eingabe als int
    @return ob das Zeichen ein Umlaut oder scharfes S ist
    */    
    ///////////////////////////////////////////////////////
    
  	private boolean isGermanLetter(int chValue){
  	    if (chValue == 252 || chValue == 246 || chValue == 228 || chValue == 223 || chValue == 220 || chValue == 214 || chValue == 196   )
  	    return true;
  	    else return false;
  	}
  	
  	///////////////////////////////////////////////////////
  	/**
  	* istSatzZeichen()
    @param chValue das aktuelle Zeichen der Eingabe als int
    @return ob das Zeichen ein ,;:!. oder ? ist
    */    
    ///////////////////////////////////////////////////////
    
  	private boolean istSatzZeichen(int chValue){
  	    if (chValue == 33 || chValue == 44 || chValue == 46 || chValue == 58 || chValue == 59 || chValue == 63)
  	    return true;
  	    else return false;
  	}
}

