package searchDesign;
import java.io.*;

//////////////////////////////////////////////////////////////////////
/**
* Zeichenfilter
* abstrakte Klasse fuer konkrete Filter wie Text- oder Hypertextfilter
*/
//////////////////////////////////////////////////////////////////////

abstract class Zeichenfilter {
    
    /* Funktionen */
    
    abstract String nextWord(boolean satzZeichenMitlesen) throws IOException;
    
    abstract public int aktuellePosition();
    
    abstract public short laeLeWort();
    
    
}
