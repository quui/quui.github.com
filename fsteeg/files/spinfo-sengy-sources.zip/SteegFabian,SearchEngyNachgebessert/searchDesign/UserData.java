package searchDesign;

/**
 *
 * <p>Description: Benutzer-spezifische Daten werden in einem UserData-Objekt
 * gespeichert un in Settings global zur Verf�gung gestellt.</p>
 * @version 1.0
 */
public class UserData {

    // Art der Ausgabe
    public TalkInterface talk;
    
    public boolean neuIndiziert = true;
    
    // Hashtable bzw. Tree als Direktzugriffsstruktur
    //public boolean useTableInIndexer;
    //public boolean useTableInKeyData;
    
    public int interneDatenstrukturIndexer = 0;
    public int interneDatenstrukturKeyData = 0;
    
    public boolean leseText = true;
    public boolean leseHypertext = true;
    public int contextLength = 1;
    public int contextAmount = 2;

    /**
     * Im Konstruktor mu� ein TalkInterface (standardm��ig ein GuiPrintStream)
     * �bergeben werden.
     * @param talk
     */
    public UserData (TalkInterface talk){
        this.talk = talk;
    }

}