package searchDesign;

import java.io.*;

/**
 *
 * <p>Beschreibung: Die Klasse Engine steuert den Haupt-Programmablauf von
 * SearchEngy. Die notwendigen Klassen wie Indexer oder QueryEngine werden
 * hier instantiiert, um anschlie�end durch die Methoden buildIndex bzw.
 * findWords das jeweilige Unterprogramm zu starten.</p>
 * @version 1.0
 */
public class Engine {

    static String indexFile,     // Pfad zur Index-Datei
                  docMapFile,    // Pfad zur DocMap-Datei
                  stopWordFile,  // Pfad zur StopWord-Datei
                  scanFolder,    // Pfad zum zu indizierenden Verzeichnis
                  resultFile;    // Pfad zur Datei, in der die Resultate der Suchanfrage gespeichert werden

    static CrawlerInterface crawler;
    static ParserInterface parser;
    static IndexerInterface indexer;
    static QueryEngineInterface query;


  /**
   * Diese Methode initialisiert die Engine durch Einlesen der Direktivendatei "SearchEngy.ini"
   */
    public static void init() {
        LineNumberReader ini; // Zum zeilenweisen Einlesen der Datei "SearchEngy.ini"
        crawler = new Crawler();
        parser = new Parser();
        indexer = new Indexer();
        query =  new QueryEngine();
        try {
            ini = new LineNumberReader(new BufferedReader(new FileReader("SearchEngy.ini")));
            // Einlesen der Informationen in der ".ini"-Datei:
            indexFile = ini.readLine();
            docMapFile = ini.readLine();
            stopWordFile = ini.readLine();
        }
        catch (java.io.IOException x) {
            Settings.user.talk.error("Die Datei \"SearchEngy.ini\" konnte nicht ge�ffnet werden."
                + "\nDas Programm wird abgebrochen.\n");
            return;
        }
    }


    /**
     * Diese Methode bildet den Index der Suchmaschine und speichert ihn auf dem indexFile.
     * Es werden dabei Zeitmessungen vorgenommen.
     * @param pathToFolder Der Pfad zum zu indizierenden Verzeichnis
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static void buildIndex(String pathToFolder) throws FileNotFoundException, IOException{
        long start, end;    // Variablen zur Zeitmessung
        Data word;          // Zwischenspeicher f�r WordData-Objekte beim Indizieren
        start = System.currentTimeMillis(); // Beginn der 1. Zeitmessung

        crawler.initialize(pathToFolder);
        parser.initialize(stopWordFile, crawler);
        //Engine.crawler = new Crawler();
        indexer.initialize(Settings.user.interneDatenstrukturIndexer);
        
        boolean einsZumindest = false;
        while ((word = parser.nextWord()) != null) {
            indexer.put(word);
            einsZumindest = true;
        }
        if(!einsZumindest)
            return; //   Abbruchbedingung fuer den Fall dass das Verzeichnis keine lesbaren Dateien enthaelt
        
        parser.writeDocMap(docMapFile);
        Settings.user.talk.message("");
        
        Settings.user.talk.message("'DocMap' - Datei geschrieben.");
        Settings.user.talk.message("");
        end = System.currentTimeMillis();
        //Settings.user.talk.message("");
        Settings.user.talk.message("Benoetigte Zeit (Indizieren): " + (double)(end-start)/1000 + " Sekunden");
        start = System.currentTimeMillis();
        indexer.saveBinary(indexFile);
        end = System.currentTimeMillis();
        Settings.user.talk.message("Benoetigte Zeit (Speichern): " + (double)(end-start)/1000 + " Sekunden");
        Settings.user.talk.message("");
        
        Settings.user.talk.message("Indizierung abgeschlossen.");
        Settings.user.talk.message("....................................................................................");
        Settings.user.neuIndiziert = true;
    }

    /**
     * Diese Methode f�hrt eine Suchanfrage durch die QueryEngine durch
     * @param words Die vom Benutzer eingegebene Suchanfrage
     */
     
    public static void findWords(String words) {
     // Abfrage des Result-Files:
        if(resultFile == null || resultFile.length() == 0) {
        //Settings.user.talk.message("Keine Ausgabedatei spezifiziert... Leite Frage ein...");
            
          resultFile = Settings.user.talk.question
          ("Bitte geben Sie die Datei an, in die die Ausgabedaten geschrieben werden sollen");
          if(resultFile == null || resultFile.length() == 0) {
            /* Wenn kein Dateiname angegeben wird, soll das Programm
            nicht ausgef�hrt werden.
            */
            Settings.user.talk.message("Keine Datei ausgewaehlt - es wird nicht gesucht.");
            return;
          }
        }
        
        
        // Initialisierung der QueryEngine:
        if(Settings.user.neuIndiziert){ //  neue flag variable fuer den Fall, dass zwischendurch neu indiziert wurde
            Settings.user.talk.message("initialisiere QueryEngine  ...  einen Moment bitte  ...  ");
            Settings.user.talk.message(" ");
            query.initialize(indexFile, docMapFile, resultFile);
            Settings.user.talk.message("QueryEngine initialisiert  ...");
            Settings.user.neuIndiziert = false;
        }
        Settings.user.talk.message("beginne Suche nach >>" + words +"<<  ...  ");
        Settings.user.talk.message(" ");
        
        // Bearbeitung der Suchanfrage:
        query.processQuery(words);
    }
}