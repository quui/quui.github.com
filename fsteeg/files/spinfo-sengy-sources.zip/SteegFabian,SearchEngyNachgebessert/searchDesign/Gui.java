package searchDesign;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.TitledBorder;
import javax.swing.border.BevelBorder;
import java.io.*;
import javax.swing.text.*;

/**
 *
 * <p>Beschreibung: Gui ist eine Klasse, durch die die grafische Oberfl�che des
 * Programms erzeugt wird. Daf�r werden die Swing-Packages von Sun benutzt,
 * die ab Java 1.3 zum Lieferumfang des JDKs geh�ren.
 * </p>
 * @version 1.0
 */

public class Gui extends JFrame {

  JMenuItem   quitMenuItem;         // "Beenden"-Menu

  JComboBox   contextWidthComboBox; // "Kontextbreite" im Suchmodus
  
  JComboBox   contextAmountComboBox; // "Kontextbreite" im Suchmodus
  
  JComboBox   indexerComboBox; // Zur Auswahl der Datenstruktur in Indexer
  JComboBox   keyDataComboBox; // Zur Auswahl der Datenstruktur in KeyData

  JTextPane   inputTextPane;        // Eingabefeld im Suchmodus

  JButton     startSearchButton,    // "Suche starten"-Button im Suchmodus
              startIndexingButton,  // "Indizierung starten"-Button im Indexmodus
              changeFolderButton;   // "Verzeichnis wechseln"-Button im Indexmodus

  JTextField  folderNameTextField;  // Zeigt ausgew�hltes Verzeichnis im Indexmodus an

  //JCheckBox   indexerCheckBox,      // Zur Auswahl der Datenstruktur in Indexer
  //            keyDataCheckBox;      // Zur Auswahl der Datenstruktur in KeyData
              
  JCheckBox   textCheckBox,      
              hypertextCheckBox;      

  Document  outputDocument;         // In dieses "Dokument" werden die Konsole-Ausgaben
                                    // umgeleitet. ("Ausgabe" im Index- und Suchmodus)

  File      selectedFolder = null;  // Speicherung des ausgew�hlten Verzeichnisses im Indexmodus
  UserData  userData;               // Enth�lt die aktuellen Einstellungen f�r Kontextbreite etc.


  // Die ausw�hlbaren Werte f�r die Kontextbreite
  String    values[]   = { "ein Wort",       "zwei W�rter",  "drei W�rter",
                        "vier W�rter",    "f�nf W�rter",  "sechs W�rter",
                        "sieben W�rter",  "acht W�rter",  "neun W�rter",
                        "zehn W�rter"
            };
            
   String    values2[]   = { "Keine",       "1",  "2",
                        "3",    "4",  "5",
                        "6",  "7",  "8",
                        "Alle"
            };

String    valuesStruktur[]   = { "sort. Binaerbaum (eigene Implementation)",       
                                 
                                 "ausg. Binaerbaum (ext. java.util.TreeMap)",
                                "Hashtable (java.util.Hashtable, leicht mod.)",  
            };

  /**
  * Diese Methode erzeugt ein JPanel, in welchem die GUI-Elemente
  * f�r den Suchmodus enthalten sind. (Also das Eingabefeld, der
  * "Suche starten"-Button und die ComboBox f�r die Auswahl der Kontextbreite).
  *
  * @return das erzeugte JPanel
  */
  private JPanel getSearchPanel() {
    // "Hintergrund"-Panel f�r den Suchmodus:
    // in dieses Panel werden die anderen Panels eingef�gt.
      JPanel searchPanel = new JPanel();

    // Panel f�r Kontextbreite-PopupMenu und Suchen-Button:
      JPanel userActionPanel = new JPanel();

    // Panel f�r das Sucheingabe-Feld:
      JPanel inputPanel = new JPanel();

    // Layout-Einstellungen setzen:
    // Die GUI-Elemente werden entweder von oben nach unten (Y_AXIS)
    // oder von links nach rechts (X_AXIS) angeordnet.
      searchPanel.setLayout(new BoxLayout(searchPanel,BoxLayout.Y_AXIS));
      userActionPanel.setLayout(new BoxLayout(userActionPanel,BoxLayout.X_AXIS));
      inputPanel.setLayout(new BoxLayout(inputPanel,BoxLayout.Y_AXIS));

    // Die "eigentlichen" GUI-Elemente:
    // 1.) Eingabefeld
      inputPanel.setBorder(new TitledBorder("Sucheingabe:"));
      inputTextPane = new JTextPane();
      inputTextPane.setMaximumSize(new Dimension(1000,200));

    // 2.) Kontextbreite-ComboBox
      contextWidthComboBox = new JComboBox(values);
      contextWidthComboBox.setMaximumSize(new Dimension(150,20));
      //contextWidthComboBox.setMinimumSize(new Dimension(80,30));
      
      // 2.) Kontextanzahl-ComboBox
      contextAmountComboBox = new JComboBox(values2);
      contextAmountComboBox.setMaximumSize(new Dimension(200,20));
      //contextAmountComboBox.setMinimumSize(new Dimension(50,30));
      

      // �bernehmen des eingestellten Wertes f�r die Kontextbreite aus userData
      contextWidthComboBox.setSelectedIndex(userData.contextLength-1);
      
      // �bernehmen des eingestellten Wertes f�r die Kontextanzahl aus userData
      contextAmountComboBox.setSelectedIndex(userData.contextAmount);

    // 3.) Suchen-Button
      startSearchButton = new JButton("Suche starten",
                                      new ImageIcon("icons" + File.separator + "Find24.gif"));

    // Einf�gen der Elemente in die Panels:
      inputPanel.add(inputTextPane);
      
      userActionPanel.add(new JLabel(" Fundstellen im Kontext ausgeben: "));
      userActionPanel.add(contextAmountComboBox);
      
      userActionPanel.add(new JLabel(" Kontextbreite: "));
      userActionPanel.add(contextWidthComboBox);
      
      userActionPanel.add(Box.createHorizontalGlue()); // Abstandhalter
      userActionPanel.add(startSearchButton);

    // Panels verschachteln:
      searchPanel.add(inputPanel);
      searchPanel.add(userActionPanel);
      searchPanel.add(Box.createVerticalBox());

    return searchPanel;
  }

  /**
   *  Diese Methode erzeugt ein JPanel, in welchem die GUI-Elemente f�r
   * den Indizierungsmodus enthalten sind.
   *
   * @return das neu erzeugte JPanel
   */
  private JPanel getIndexPanel() {

      // "Hintergrund"-Panel f�r den Index-Modus:
      // In diesem Panel werden die weiteren Panels eingef�gt
      JPanel indexPanel = new JPanel();

      // Das "obere" Panel ("Zu indizierendes Verzeichnis")
      // Ihm werden Suchfeld und changePanel (mit "Verzeichnis wechseln"-Button)
      // zugef�gt.
      JPanel upperPanel = new JPanel();

      // Das "untere" Panel ("Datenstruktur"/"Indizierung starten")
      // Ihm werden choicePanel und startPanel zugef�gt
      JPanel lowerPanel = new JPanel();

      // Panel f�r den "Indizierung starten"-Button
      JPanel startPanel = new JPanel();

      // Panel f�r den "Verzeichnis wechseln"-Button
      JPanel changePanel = new JPanel();

      // Panel f�r die Datenstruktur-Comboboxes
      JPanel choicePanel = new JPanel();
      
      // Panel f�r die Indexer Datenstruktur
      JPanel indexerChoicePanel = new JPanel();
      
      // Panel f�r die KD Datenstruktur
      JPanel kdChoicePanel = new JPanel();
      
      // Panel fuer die Dokumentenwahl
      JPanel docChoicePanel = new JPanel();
      
      

    // Layout-Einstellungen setzen:
    // Die GUI-Elemente werden entweder von oben nach unten (Y_AXIS)
    // oder von links nach rechts (X_AXIS) angeordnet.
      indexPanel.setLayout(new BoxLayout(indexPanel,BoxLayout.Y_AXIS));
      upperPanel.setLayout(new BoxLayout(upperPanel,BoxLayout.Y_AXIS));
      startPanel.setLayout(new BoxLayout(startPanel,BoxLayout.Y_AXIS));
      changePanel.setLayout(new BoxLayout(changePanel,BoxLayout.X_AXIS));
      choicePanel.setLayout(new BoxLayout(choicePanel,BoxLayout.X_AXIS));
      indexerChoicePanel.setLayout(new BoxLayout(indexerChoicePanel,BoxLayout.Y_AXIS));
      kdChoicePanel.setLayout(new BoxLayout(kdChoicePanel,BoxLayout.Y_AXIS));
      //BevelBorder vorlage = new BevelBorder(3);
      //indexerChoicePanel.setBorder(new TitledBorder(vorlage, "interne Datenstruktur im Indexer"));
      //kdChoicePanel.setBorder(new TitledBorder(vorlage, "interne Datenstruktur im Indexer"));
      
      docChoicePanel.setLayout(new BoxLayout(docChoicePanel,BoxLayout.Y_AXIS));
      lowerPanel.setLayout(new BoxLayout(lowerPanel,BoxLayout.X_AXIS));

      upperPanel.setBorder(new TitledBorder("Zu indizierendes Verzeichnis:"));
      choicePanel.setBorder(new TitledBorder("interne Datenstruktur"));
      docChoicePanel.setBorder(new TitledBorder("Dateien"));
      
    // Die "eigentlichen" GUI-Elemente:
    // 1.) Das Textfeld mit dem zu indizierenden Verzeichnis:
      folderNameTextField = new JTextField("(keine Auswahl)");
      folderNameTextField.setBackground(indexPanel.getBackground()); // Sieht sch�ner aus.
      folderNameTextField.setEditable(false);
      folderNameTextField.setBorder(null);                        // Sieht sch�ner aus.
      folderNameTextField.setMaximumSize(new Dimension(1000,30)); // Sieht sch�ner aus.


    // 2.) Der "Verzeichnis wechseln"-Button:
      changeFolderButton = new JButton("Verzeichnis wechseln",
                               new ImageIcon("icons" + File.separator + "Open24.gif"));

    // 3.) "Indizierung starten"-Button:
    startIndexingButton = new JButton("Indizierung starten",
                                new ImageIcon("icons" + File.separator + "New24.gif"));

    // 4.) Buttons zur Auswahl der Datenstruktur:
    //indexerCheckBox = new JCheckBox("Hashtable in Indexer benutzen");
    //keyDataCheckBox = new JCheckBox("Hashtable in KeyData benutzen");
    //indexerCheckBox.setSelected(userData.useTableInIndexer);  // Aktuelle Einstellung aus userData �bernehmen
    //keyDataCheckBox.setSelected(userData.useTableInKeyData);  // Aktuelle Einstellung aus userData �bernehmen
    
      // x.) indexer-ComboBox
      indexerComboBox = new JComboBox(valuesStruktur);
      indexerComboBox.setMaximumSize(new Dimension(290,20));
      //contextWidthComboBox.setMinimumSize(new Dimension(80,30));
      
      // y.) keyData-ComboBox
      keyDataComboBox = new JComboBox(valuesStruktur);
      keyDataComboBox.setMaximumSize(new Dimension(290,20));
      //contextAmountComboBox.setMinimumSize(new Dimension(50,30));
      

      // �bernehmen des eingestellten Wertes f�r die indexer-ComboBox
       indexerComboBox.setSelectedIndex(userData.interneDatenstrukturIndexer);
      
      // �bernehmen des eingestellten Wertes f�r die keyData aus userData
      keyDataComboBox.setSelectedIndex(userData.interneDatenstrukturKeyData);

    
    // 5.) Buttons zur Auswahl der Dateien
    textCheckBox = new JCheckBox("text");
    hypertextCheckBox = new JCheckBox("html");
    textCheckBox.setSelected(userData.leseText);  // Aktuelle Einstellung aus userData �bernehmen
    hypertextCheckBox.setSelected(userData.leseHypertext);  // Aktuelle Einstellung aus userData �bernehmen


    // Einf�gen der Elemente in die Panels:
    changePanel.add(changeFolderButton);
    changePanel.add(Box.createHorizontalGlue());  // Abstandhalter
    
    upperPanel.add(folderNameTextField);

    startPanel.add(Box.createVerticalGlue());     //Abstandhalter
    startPanel.add(startIndexingButton);
    //startPanel.add(Box.createVerticalGlue());     //Abstandhalter
    //startPanel.add(Box.createHorizontalGlue());     //Abstandhalter
    
    indexerChoicePanel.add(Box.createVerticalGlue());     //Abstandhalter
    
    indexerChoicePanel.add(new JLabel("im Indexer:  "));
    indexerChoicePanel.add(Box.createVerticalGlue());     //Abstandhalter
    
    indexerChoicePanel.add(new JLabel("in KeyData:  "));
    indexerChoicePanel.add(Box.createVerticalGlue());     //Abstandhalter
   
    
    kdChoicePanel.add(indexerComboBox); 
    kdChoicePanel.add(Box.createVerticalGlue());     //Abstandhalter
    kdChoicePanel.add(keyDataComboBox);
    kdChoicePanel.add(Box.createVerticalGlue());     //Abstandhalter
    
    choicePanel.add(indexerChoicePanel);
    choicePanel.add(kdChoicePanel);
    //choicePanel.add(Box.createHorizontalGlue()); // Abstandhalter
    
    
    
    docChoicePanel.add(textCheckBox);
    docChoicePanel.add(hypertextCheckBox);

    // Panels verschachteln:
    upperPanel.add(changePanel);
    lowerPanel.add(docChoicePanel);
    lowerPanel.add(choicePanel);
    
    
    
    
    lowerPanel.add(Box.createHorizontalGlue());   // Abstandhalter
    lowerPanel.add(startPanel);

    indexPanel.add(upperPanel);
    indexPanel.add(lowerPanel);

    return indexPanel;
  }

  /**
   * Durch diese Funktion wird eine Menuleiste erzeugt und
   * in das Hauptfenster eingef�gt.
   */
/*
  private void createMenuBar() {
    JMenuBar menuBar    = new JMenuBar();
    JMenu fileMenu      = new JMenu("Datei");
    quitMenuItem        = new JMenuItem("Beenden");
    fileMenu.add(quitMenuItem);
    menuBar.add(fileMenu);
    setJMenuBar(menuBar);
  }
*/
  /**
   * Diese Methode erzeugt ein JPanel mit scrollbarem Textfeld,
   * in das die Programm-Ausgaben (unabh�ngig davon, ob sie �ber
   * das TalkInterface oder den Standard-OutputStream "System.out" erzeugt
   * wurden) umgeleitet werden.
   *
   * @return ein JPanel, in welches das Textfeld eingebettet wurde.
   */
  private JPanel getOutputPanel() {
    JPanel outputPanel = new JPanel(new BorderLayout());
    JTextPane outputPane = new JTextPane();
    outputDocument = outputPane.getDocument();
    outputPane.setMinimumSize(new Dimension(100,60));
    outputPane.setPreferredSize(new Dimension(100,60));
    outputPanel.setBorder(new TitledBorder("Programm-Ausgabe"));

    JScrollPane scrollPane = new JScrollPane(outputPane);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    outputPanel.add(scrollPane,BorderLayout.CENTER);
    return outputPanel;
  }

  /**
   * Diese Methode initialisiert die grafische Benutzeroberfl�che f�r
   * SearchEngy. Dazu benutzt sie in erster Linie die Methoden
   * createMenuBar(), getIndexPanel(), getOutputPanel() und getSearchPanel()
   */

  private void initComponents() {
    //createMenuBar();            // Menubar wird erzeugt
    setSize(640,450);           // Gr��e des Fensters
    setTitle("SearchEngy");     // Titel des Fensters (in Menuleiste)

    getContentPane().setLayout(
              new BoxLayout(getContentPane(),BoxLayout.Y_AXIS));

    // Spezielles Panel mit "Karteikarten-Reiterchen" f�r
    // Suchmodus und Indizierungsmodus
      JTabbedPane tabPanel = new JTabbedPane(JTabbedPane.TOP);

      tabPanel.addTab("Suchmodus",getSearchPanel());
      tabPanel.addTab("Indizierungsmodus",getIndexPanel());

      getContentPane().add(tabPanel);         // Im oberen Teil des Fensters
                                              // wird das tabPanel angezeigt

      getContentPane().add(getOutputPanel()); // Im unteren Teil wird
                                              // die Programmausgabe angezeigt
  }

  /**
   * Diese Methode l�scht den Inhalt des Ausgabefensters und startet
   * die Suche nach den eingegebenen W�rtern und Wortketten.
   */

private void startSearch() {
  try {
    outputDocument.remove(0,outputDocument.getLength());
  } catch (BadLocationException x) {
    x.printStackTrace();
  }
  
  // zur ausgabe waehrend der suche
   final Thread updater = new Thread(){
        public void run(){
           
        try{
               
                    
                //Thread.sleep(1000);
  					//Settings.user.talk.message("Leite Suchprozedur ein...");
                Engine.findWords(inputTextPane.getText());
                   
        }
        catch(Throwable erx){}
        }
    };
    updater.start();
        
 
 
}


/**
 * Hier werden die GUI-Elemente, die auf Benutzereingaben reagieren sollen,
 * durch Listener mit den jeweiligen Methoden verkn�pft. So erh�lt der Menupunkt
 * "Beenden" beispielsweise die Methode "System.exit(0)".
 */

private void initListeners() {
/*
  quitMenuItem.addActionListener(new ActionListener() {
      // Programm beenden:
      public void actionPerformed(ActionEvent e) {
        System.exit(0);
      }
    });
*/
  changeFolderButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      JFileChooser fileChooser;  // Ein Datei-Dialog
      if(selectedFolder == null) {
        fileChooser = new JFileChooser(".");
      } else {
        fileChooser = new JFileChooser(selectedFolder.getParentFile());
        fileChooser.setSelectedFile(selectedFolder);
      }
      fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
      fileChooser.setMultiSelectionEnabled(false);
      fileChooser.setDialogTitle("Bitte w�hlen Sie ein Verzeichnis aus");
      int result = fileChooser.showOpenDialog(Gui.this);
      if(result == JFileChooser.APPROVE_OPTION) {
        selectedFolder = fileChooser.getSelectedFile();
        folderNameTextField.setText(selectedFolder.getAbsolutePath());
      }
    }
  });
/*
  keyDataCheckBox.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      userData.useTableInKeyData = keyDataCheckBox.isSelected();
    }
  });

  indexerCheckBox.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      userData.useTableInIndexer = indexerCheckBox.isSelected();
    }
  });
*/
  hypertextCheckBox.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      userData.leseHypertext = hypertextCheckBox.isSelected();
    }
  });

  textCheckBox.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      userData.leseText = textCheckBox.isSelected();
    }
  });

  contextWidthComboBox.addItemListener(new ItemListener() {
    public void itemStateChanged(ItemEvent e) {
      if(e.getStateChange() == ItemEvent.SELECTED) {
        String choice = (String) e.getItem();
        for(int i = 0; i < values.length; i++) {
          if(values[i].compareTo(choice) == 0) {
            Settings.user.contextLength = i+1;
            break;
          }
        }
      }
    }
  });
  
   contextAmountComboBox.addItemListener(new ItemListener() {
    public void itemStateChanged(ItemEvent e) {
      if(e.getStateChange() == ItemEvent.SELECTED) {
        String choice = (String) e.getItem();
        for(int i = 0; i < values2.length; i++) {
          if(values2[i].compareTo(choice) == 0) {
            if(i == values2.length-1) 
                Settings.user.contextAmount = 9999;
            else
                Settings.user.contextAmount = i;
                
            break;
          }
        }
      }
    }
  });
  
  
  
  indexerComboBox.addItemListener(new ItemListener() {
    public void itemStateChanged(ItemEvent e) {
      if(e.getStateChange() == ItemEvent.SELECTED) {
        String choice = (String) e.getItem();
        for(int i = 0; i < valuesStruktur.length; i++) {
          if(valuesStruktur[i].compareTo(choice) == 0) {
            Settings.user.interneDatenstrukturIndexer = i;
            break;
          }
        }
      }
    }
  });
  
   keyDataComboBox.addItemListener(new ItemListener() {
    public void itemStateChanged(ItemEvent e) {
      if(e.getStateChange() == ItemEvent.SELECTED) {
        String choice = (String) e.getItem();
        for(int i = 0; i < valuesStruktur.length; i++) {
          if(valuesStruktur[i].compareTo(choice) == 0) {
            Settings.user.interneDatenstrukturKeyData = i;
            break;
          }
        }
      }
    }
  });
  
  
  
  
  
  
  
  
  
  
  
  
  
  

  startIndexingButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      try {
        if(selectedFolder == null) {
          // Anmerkung: "Gui.this" ist ziemlich strange... aber cool!
          JOptionPane.showConfirmDialog(Gui.this,"Bitte w�hlen Sie zuerst ein Verzeichnis aus.",
          "Welches Verzeichnis indizieren?",JOptionPane.DEFAULT_OPTION,JOptionPane.PLAIN_MESSAGE);
          return;
        }
        outputDocument.remove(0,outputDocument.getLength());
        
        //   zur gleichzeitigen ausfuehrung und darstellung...
        final Thread updater = new Thread(){
            public void run(){
           
            try{
               
                    
                    //Thread.sleep(1000);
  					Engine.buildIndex(selectedFolder.getAbsolutePath());
                   
            }
            catch(Throwable erx){}
            }
        };
        updater.start();
        
        
        
        
        
        
        
      } catch (Exception x) {
        x.printStackTrace();
      }
    }
  });

  startSearchButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
      startSearch();
    }
  });

  inputTextPane.addKeyListener(new KeyAdapter() {
    public void keyPressed(KeyEvent e) {
      if(e.getKeyCode()== KeyEvent.VK_ENTER) { // Enter- und Returntaste werden abgefangen
        startSearch();
        e.consume(); // Sonst wird gesucht UND Enter ins Textfeld eingef�gt
      }
    }
  });

  this.addWindowListener(new WindowAdapter() {
    public void windowClosing(WindowEvent e) {
     System.exit(0);
    }
  });
}

  public Gui(UserData ud) {
    try {
      /* hier wird versucht, das "Look-And-Feel" des Programms an das
         Look-And-Feel des jeweiligen Betriebssystems anzupassen.
      */
      String defaultLAF = UIManager.getSystemLookAndFeelClassName();
      UIManager.setLookAndFeel(defaultLAF);
      SwingUtilities.updateComponentTreeUI(this);
    } catch (Exception x) {
      System.out.println("System-Look-And-Feel (" + "  " + ") konnte nicht "
      + "initialisiert werden.\nDetails:");
      x.printStackTrace();
    }

    userData = ud;
    initComponents(); // Erzeugen der GUI-Elemente
    initListeners();  // Verkn�pfung der Buttons etc. mit Methoden
    setVisible(true); // Fenster anzeigen

    try {
      //Initialisierung der Suchmaschine (Engine:
      Engine.init();
      // Die I/O-Schnittstelle des Programms wird auf die GUI umgestellt:
      userData.talk = new GuiPrintStream(outputDocument,this); // guiOut ist  TalkInterface!
    } catch (IOException x) {
      System.out.println("GuiPrintStream konnte nicht initialisiert werden!");
      System.out.println("Die grafischen IO-Elemente werden nicht genutzt.");
      System.out.println("Details:");
      x.printStackTrace();
    }
  }

}