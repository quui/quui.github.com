package searchDesign;

/**
 *
 * <p>Beschreibung: Die QueryEngine bearbeitet die Suchanfragen. </p>
 * @version 1.0
 */

public interface QueryEngineInterface {

  /**
   * Initialisierungsmethode:
   * Liest die Indexdatei indexFile ein und rekonstruiert daraus den
   * invertierten Index. Um Rankingberechnungen und Kontextausgaben machen zu
   * k�nnen, ben�tigt die QueryEngine die Informationen aus der Datei
   * docMapFile, die beim Indizieren vom Parser angelegt wurde. In der Datei
   * resultFile werden die Suchergebnisse gespeichert.
   *
   * @param indexFile  Pfad zur Indexdatei
   * @param docMapFile Pfad zur DocMap-Datei
   * @param resultFile Pfad zur Ausgabedatei
   */
    public void initialize (String indexFile, String docMapFile, String resultFile);

    /**
     * Bearbeitet eine Suchanfrage.
     * Term ist die Benutzereingabe, welche eine beliebige Kombination von
     * W�rtern und/oder Wortketten enth�lt. Eine Wortkette bezeichnet
     * aufeinander folgende W�rter in doppelten Anf�hrungszeichen,
     * z.B. "b�se Hexe". term wird in seine einzelnen Bestandteile geparst.
     * Es m�ssen alle Dokumente ermittelt werden, die alle W�rter des Terms
     * enthalten. Hier sollte man sich alle Dokumente merken, in denen der
     * erste Term enthalten ist, und die Schnittmenge von dieser
     * Dokumentenmenge und den Dokumentenmengen der weiteren Terme der
     * Suchanfrage bilden. Bei der Behandlung von Wortketten muss verifiziert
     * werden, dass die einzelnen W�rter einer Wortkette adjazent sind. Die
     * n�tigen Informationen daf�r sind in den Fundstellen enthalten. F�r die
     * Ausgabe werden die ermittelten Dokumente nach dem Ranking mit Hilfe von
     * Quicksort sortiert. Anschlie�end gibt processQuery die Suchergebnisse
     * sowohl auf dem Bildschirm als auch in die Ausgabedatei resultFile aus. 
     * F�r die Ausgabe der KeyWords im Kontext bietet es sich an, 
     * diesen mittels eines RandomAccessFiles aus den entsprechenden Dokumenten 
     * zu holen. F�r die Ausgabe wird der Originaltext wie in der globalen 
     * Beschreibung unter 3.3.3 beschrieben leicht aufbereitet.
     *
     * @param term Die eingegebene Suchanfrage
     */
    public void processQuery(String term);


}