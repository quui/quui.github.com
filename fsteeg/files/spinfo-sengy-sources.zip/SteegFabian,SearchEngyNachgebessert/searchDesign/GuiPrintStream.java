package searchDesign;

import java.io.*;
import javax.swing.JOptionPane;
import java.awt.Component;
import javax.swing.text.*;

/**
 * <p>Description: Diese Klasse implementiert genau wie die Klasse ConsoleTalk
 * das Interface TalkInterface. Durch GuiPrintStream werden die Ein- und Ausgaben
 * des Programms in die grafische Benutzeroberfl�che der Klasse Gui umgelenkt.</p>
 * @version 1.0
 */
public class GuiPrintStream extends java.io.PrintStream implements TalkInterface{

  private Document outDocument; // Das Document, in das geschrieben wird
  private Component parent;     // Die Grafik-Komponente, �ber der Dialoge gezeigt werden
  private final String encoding = "Cp437";


  /**
   * Sollte aufgerufen werden, wenn eine Fehlermeldung angezeigt werden soll.
   * Falls es sich um eine Exception handelt, wird ein Dialogfenster angezeigt.
   * @param output Die Fehlermeldung
   */
  public void error(String output) {
    println(output);
    JOptionPane.showConfirmDialog(parent,
        output,
    "Ein Fehler ist aufgetreten",
    JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
  }

  public void message(String output) {
    println(output);
  }

  /**
   * Diese Methode �ffnet einen Input-Dialog und gibt die Benutzereingabe
   * zur�ck an die aufrufende Methode.
   * @param question Die Frage bzw. Mitteilung, die angezeigt werden soll
   * @return String mit der eingegebenen Antwort oder null, falls auf
   * "Cancel" geklickt wurde.
   */

  public String question(String question) {
    return JOptionPane.showInputDialog(parent,question,"Frage",JOptionPane.QUESTION_MESSAGE);
  }

  /**
   * Der Konstruktor GuiPrintStream wird mit zwei GUI-Komponenten
   * aufgerufen.
   * @param doc Das "Document", in welches Programmausgaben geleitet werden
   * sollen. Dieses wird im "Ausgabe"-Feld dargestellt
   * @param parent Das Fenster, �ber dem Fehler- und Eingabedialoge
   * angezeigt werden sollen
   * @throws IOException Falls bei der Umstellung der System-Streams f�r
   * Ein- und Ausgabe ein Fehler auftritt.
   */
  GuiPrintStream(Document doc, Component parent) throws IOException{
    super(System.out,true);
    outDocument = doc;
    this.parent = parent;
    System.setOut(this);
    System.setErr(this);
  }

  /**
   *  Die write-Methoden �berschreiben die Methoden aus PrintStream
   *  und leiten so die Ausgabe in das GUI-Fenster um.
   * (Siehe write(String toWrite)).
  */
  public void write(int i) {
    char toWrite[] ={(char)i};
    write(toWrite);
  }

  public void write(byte buf[], int off, int len) {
    try {
    String toWrite = new String(buf,off,len,encoding);
    write(toWrite);
    } catch (UnsupportedEncodingException x) {
      x.printStackTrace();
    }
  }

  private void write(char[] toWrite) {
    write(new String(toWrite));
  }

  /**
   * Diese Methode sorgt daf�r, da� ein String, der beispielsweise
   * durch die Methode println ausgegeben werden soll, im Ausgabefeld
   * angezeigt wird.
   * @param toWrite
   */
  private void write(String toWrite) {
    try {
    outDocument.insertString(outDocument.getLength(),toWrite,null);
    } catch (Exception x) {
      x.printStackTrace();
    }
  }

  public void println(String toPrint) {
    write(toPrint + "\n");
  }

  /**
   * Falls das �bergebene Object eine Instanz der Klasse Throwable ist
   * (wie beispielsweise Errors oder Exceptions), wird zus�tzlich zur normalen
   * Ausgabe im Ausgabe-Fenster auch noch ein Dialog mit einer Warnung
   * angezeigt.
   * @param toPrint Das Objekt, das ausgegeben werden soll.
   */
  public void println(Object toPrint) {
    /*if(toPrint instanceof Throwable) {
      JOptionPane.showConfirmDialog(parent,"Ein Fehler ist aufgetreten:"
      + "\n\n" + toPrint.toString() + "\n\nDetails finden Sie im Ausgabefenster",
      "Fehlermeldung",JOptionPane.DEFAULT_OPTION,JOptionPane.ERROR_MESSAGE);
    }*/
    write(String.valueOf(toPrint) + "\n");
  }
 }