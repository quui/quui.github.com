package searchDesign;

/**
 *
 * <p>Beschreibung: KeyDataInterface wird von der Klasse KeyData
 * implementiert, welche eine Spezialisierung der abstrakten Klasse Data ist.
 * Ein KeyData speichert ein Schl�sselwort und eine Direktzugriffsstruktur mit
 * DocumentData-Objekten, die jeweils die Fundstellen des Schl�sselwortes
 * in einem Text enthalten.</p>
 * @version 1.0
 */


public interface KeyDataInterface {


  /**
   * Funktion, die aufgerufen werden muss, wenn eine Klasse,
   * die dieses Interface implementiert, initialisiert werden soll.
   *
   * In dieser Funktion muss anhand der Informationen aus Settings.user
   * entschieden werden, ob die DocumentData in einer Hashtable oder in
   * einem Bin�rbaum gespeichert werden
   *
   * @param key
   * Schl�sselwort
   *
   * @param position
   * Byte-Position des ersten Buchstaben von key im Text
   *
   * @param space
   * Anzahl der Nichtwortzeichen (inkl. HTML-Tags) zwischen key und dem
   * vorigen Wort (unabh�ngig davon, ob letzteres ein Stopwort ist oder nicht)
   * im Text
   *
   * @param docID vom Parser verwaltete ID des aktuellen Dokuments, die auch
   * in der docmap-Datei gespeichert wird
   */

public void initialize (String key, int position, short space, int docID);

/**
 * gibt die Direktzugriffsstruktur als StorageInterface zur�ck, welche alle
 * DocumentData von KeyData enth�lt
 * @return das StorageInterface mit den entsprechenden DocumentData-Objekten
 */

 public StorageInterface getDocuments();

}