package searchDesign;
import java.io.*;
import java.util.Hashtable;

///////////////////////////////////////////////////////////////////////////////
/** 
* <p> Beschreibung: Ein simpler HypertextFilter, erweitert die abstrakte Klasse
* Zeichenfilter, dient zum Lesen von Streams auf HTML (Hypertest Markup 
* Language) Dokumenten. Er filtert tags aus und wandelt Sonderzeichen um, die in
* einer Datei festgelegt sind (in der Form: Auml, blank, Zeilenumbruch)
* diese wird mit einem LineNumberedReader eingelesen. Er verfuegt in seiner 
* nextWord(), die das naechste Wort der Eingabe liefert ueber eine Option,
* ob Satzzeichen (.,:;?!) ueberlesen oder mitgelesen werden.
* </p>
* @author Fabian Steeg
*/  
//////////////////////////////////////////////////////////////////////////////

class Hypertextfilter extends Zeichenfilter { 
                                              
    /* Attribute */
    
    private BufferedReader reader;
    private int chValue;
    
    private int aktuellesDokument;
    private int aktuellePosition;
    private int firstOfLast;
    
    //   fuer HTML Tags und Sonderzeichen
    private boolean inTag;
    private boolean inSpecial;
    private boolean wasSpecial;
    private Hashtable HTMLCodes;
    private Buffer buffer;
    /* Konstruktoren */
    
    Hypertextfilter () throws IOException{
        this.aktuellePosition = 0;
        this.buffer = new Buffer();
        
    }
    
    //   zum Benutzen mit einem CharArrayReader, bei Ausgabe des Kontext
    Hypertextfilter (Reader rd) throws IOException{
        this.reader = new BufferedReader(rd);
        this.aktuellePosition = 0;
        this.buffer = new Buffer();
        
    } 
    Hypertextfilter (BufferedReader rd) throws IOException{
        this.reader = rd;
        this.aktuellePosition = 0;
        this.buffer = new Buffer();
        
    } 
    Hypertextfilter (File f) throws IOException{
        this.reader = (new BufferedReader(new FileReader(f)));
        this.aktuellePosition = 0;
        this.buffer = new Buffer();
        
    }
    
    ////////////////////////////////////////////////////////////////////////
    /** 
    * <p> Beschreibung: liefert die Laenge des zuletzt gelesenen Wortes </p>
    * @return Laenge des letzten Worte als short
    */  
    ////////////////////////////////////////////////////////////////////////
    
    public short laeLeWort(){
        return (short) (this.aktuellePosition - this.firstOfLast);
    }
    
    /////////////////////////////////////////////////////////////////////
    /** 
    * <p> Beschreibung: Liefert die aktuelle Position in der Eingabe </p>
    * @return die aktuelle Position als int
    */  
    /////////////////////////////////////////////////////////////////////
        
    public int aktuellePosition(){
        return this.aktuellePosition;
    }
    
    /////////////////////////////////////////////////////////////////////
    /** 
    * <p> Beschreibung: Initialisierungsfunktion, liest die HTMLCodes
    * aus der Datei in eine Hashtable</p>
    * @param HTMLCodesPath der Pfad zu der Datei
    */  
    /////////////////////////////////////////////////////////////////////
    
    public void initialize(String HTMLCodesPath) throws IOException{
        try{
            LineNumberReader ini;
            ini = new LineNumberReader(new BufferedReader(new FileReader(HTMLCodesPath)));
            // Einlesen der Informationen in der "HTMLCodes"-Datei:
            String HTMLCodesWort = new String(); 
            String HTMLRiZei = new String(); //   das richtige, einzusetzende Zeichen
            HTMLCodes = new Hashtable();
            while((HTMLCodesWort = ini.readLine()) != null && (HTMLRiZei = ini.readLine()) != null ){
                HTMLCodesWort=HTMLCodesWort.substring(0,HTMLCodesWort.length()-1);
                HTMLCodes.put(HTMLCodesWort, HTMLRiZei);
            }
        }
        catch (Throwable erx) { // Error or Exception
           Settings.user.talk.error("Fehler beim Schreiben der 'DocMap' - Datei im Parser:\n" + erx  + "\nGenaueres finden Sie in der Programmausgabe");
           erx.printStackTrace();
        }
    }
    
    /////////////////////////////////////////////////////////////////////
    /** 
    * <p> Beschreibung: nextWord() liefert nach Zwischenspeicherung
    * in einem Buffer das naechst Wort der Eingabe,
    * das kein Tag ist, Sonderzeichen werden enstsprechen der 
    * vorgegebenen Liste ersetzt </p>
    * @param satzZeichenMitlesen Flag zur Wahl des Lesemodus
    * @return das naechste Wort der Eingabe, das kein Tag ist oder null,
    * wenn das Ende der Datei erreicht ist.
    */  
    /////////////////////////////////////////////////////////////////////
    
     
    public String nextWord(boolean satzZeichenMitlesen) throws IOException {
        
        //   fuer die Satzzeichen - Option
		boolean leseBedingung;
		
	    //   buffer zum sammeln des kodierten Sonderzeichens
        Buffer spezial = new Buffer();
        
		//   Zeichen ueberlesen bis zum ersten Buchstaben
        while ( chValue != -1 && !isLetter(chValue)  || inTag){
            if(chValue == '&')
            	inSpecial = true;
            if(chValue == 60)
            	inTag = true;
            		
            chValue = reader.read();
            this.aktuellePosition++;
            		
            if(chValue == '<')
            	inTag = true;
            if(chValue == '>')
            	inTag = false;
            		
        }
        if (chValue == -1)
           	return null;
           	
        this.buffer.reset();//Buffer buffer = new Buffer();
        
        // ein Buffer.reset, 
        // welches den Buffer fuer eine erneute Benutzung zurecksetzt,
        // so kommt man mit nur einem Buffer-Objekt aus.
        
        this.firstOfLast = this.aktuellePosition;
        
        //   zu Lesende Zeichen lesen
        do {
        	if(chValue == ';' && inSpecial){
            		inSpecial = false;
            		wasSpecial = true;
            }    
            if(inSpecial)
                //   solange in einem kodierten Sonderzeichen
                //   gelesen wird, dieses an den spezial buffer anhaengen
            	spezial.append((char)chValue);
            	
            else{
                
            	if(chValue == '&'){
            		inSpecial = true;
            		    
            	}
            	if(!inSpecial){
            	    //   wenn eine Kodierung gelesen wurde
        	        if(wasSpecial){ 
        	            //   das zugehoerige Sonderzeichen aus
        	            //   der Hashtable holen...
        	            Object sp = spezial.toString();
        	            Object erg = this.HTMLCodes.get(sp);
			    /* 
			    if(erg == null)
				Settings.user.talk.message("ung�ltige oder unerkannte HTML-Sonderzeichenkodierung enthalten");
			    inaktiv, weil irgendein Fehler, den ich nicht mehr beheben konnte verhindert,
			    dass zwei kodierte zeichen hintereinander richtig gelesen werden...
			    */
        	            String umlautS = (String) erg ;
        	            if(umlautS != null){
        	                char umlaut = umlautS.charAt(0);
        	                buffer.append(umlaut);
        	            }
        	            wasSpecial = false;
        	        }
        	        else{
        	            //   und an den Buffer haengen der als 
        	            //   String zureuckgegeben werden soll
            		    buffer.append((char)chValue);
            	    }
            	}
            }
            chValue = reader.read(); //   weiterlesen
            this.aktuellePosition++;
            	
            if(satzZeichenMitlesen)
                leseBedingung = (isLetter(chValue) || chValue == '&' || (chValue == ';' && inSpecial) || istSatzZeichen(chValue));
            else
                leseBedingung = (isLetter(chValue) || chValue == '&' || (chValue == ';' && inSpecial));
        }
        //   Bedingung zum Weiterlaufen ueber Stream: je nach uebergebenem parameter
       	while ( leseBedingung );
            return buffer.toString();
    }
    
    ///////////////////////////////////////////////////////
    /**
    * isLetter()
    @param das aktuelle Zeichen der Eingabe als int
    @return ob das Zeichen ein Buchstabe des Englischen ist
    */	
    ///////////////////////////////////////////////////////
    	
  	private boolean isLetter(int chValue){
  	    if (chValue != -1   &&   chValue >= 65 && chValue <= 90 && chValue != -1  || chValue >=97 && chValue <= 122 && chValue != -1   )
  	    return true;
  	    else return false;
  	}
  	
    //////////////////////////////////////////////
    /**
  	* istSatzZeichen()
    @param das aktuelle Zeichen der Eingabe als int
    @return ob das Zeichen ein ,;:!. oder ? ist
    */  
    ///////////////////////////////////////////////
    
    private boolean istSatzZeichen(int chValue){
  	    if (chValue == 33 || chValue == 44 || chValue == 46 || chValue == 58 || chValue == 59 || chValue == 63)
  	    return true;
  	    else return false;
  	}
}

