package searchDesign;

import java.io.*;

/**
 *
 * <p>Beschreibung: Der Parser wird �ber die Methode initialize mit einer
 * Stopwort-Datei und einem Crawler initialisiert. Er bearbeitet
 * sequentiell alle Dateien, die der Crawler ihm zur Verf�gung stellt
 * mit seiner Methode nextWord. Die Methode nextWord gibt erst null zur�ck,
 * wenn das letzte Wort der letzten Datei abgearbeitet wurde. Nachdem er alle
 * Dateien abgearbeitet hat, erzeugt der Parser eine docMap-Datei
 * (Methode writeDocMap, s.u.) und schreibt die Pfade der bearbeiteten Dateien,
 * jeweils gefolgt (in einer neuen Zeile) von der Anzahl der eingelesenen
 * Nichtstopw�rter.</p>
 * @version 1.0
 */

public interface ParserInterface {

  /**
   * Initialisierungsmethode
   * @param stopWordFileName Der Pfad zu der Datei, die die Stopw�rter enth�lt
   * @param crawler Der zuvor erzeugte Crawler
   *
   * @throws java.io.FileNotFoundException
   * @throws java.io.IOException
   */
    public void initialize (String stopWordFileName, CrawlerInterface crawler)
                        throws java.io.FileNotFoundException, java.io.IOException;


    /**
     * schreibt in der DocMap-Datei mit Namen fileName folgende Informationen: <br>
     * - in der ersten Zeile: die Anzahl der bearbeiteten Dateien <br>
     * - danach jeweils den Pfad zu einer bearbeiteten Datei, gefolgt in einer
     * eigenen Zeile von der Anzahl der in der betroffenen Datei eingelesenen
     * Nichtstopw�rter.<br>
     * Die DocMap-Datei enth�lt keine Leerzeilen
     * @param fileName Der Pfad zur DocMap-Datei
     */
    public void writeDocMap(String fileName);

    /**
     * liefert jeweils ein Wort zur�ck, in Form eines KeyData.
     * Der Parser ber�cksichtigt nur Nichtstopw�rter, d.h. Stopw�rter
     * werden �berlesen. Bei Nichtstopw�rtern gibt der Parser ein KeyData zur�ck.
     * Ein KeyData enth�lt: <br>
     * - den eingelesenen String als key (klein geschrieben), <br>
     * - die Anfangsposition des Wortes, <br>
     * - den Abstand zwischen dem vorigen und dem eingelesen Wort im Text, d.h. die Anzahl
     *   der Nichtwortzeichen zwischen den beiden W�rtern, <br>
     * - die ID (int) des Dokuments, in dem das Wort enthalten ist. <br>
     * Es wird immer der Abstand zum tats�chlichen vorigen Wort im Text gespeichert,
     * unabh�ngig davon, ob dieses ein Stopwort ist oder nicht.
     *
     * @return ein Keydata-Objekt mit oben beschriebenem Inhalt oder null
     * @throws java.io.IOException
     * @throws java.io.FileNotFoundException
     */
    public Data nextWord() throws java.io.IOException, java.io.FileNotFoundException;
}