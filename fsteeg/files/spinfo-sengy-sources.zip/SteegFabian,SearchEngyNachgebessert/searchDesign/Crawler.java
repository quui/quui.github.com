package searchDesign;

import java.io.*;
import java.util.Vector;

/////////////////////////////////////////////////////////////////////////////////////////////
/**
* <p>Beschreibung: Ein Crawler speichert die Pfade der Text-Dateien (.txt, .html und .htm),
* die sich im �bergebenen Verzeichnis und in seinen Unterverzeichnissen befinden.
* Er geht daf�r durch das ihm in der Methode initialize �bergebene Startverzeichnis
* und dessen Verzeichnisse rekursiv durch und speichert die Pfade der darin gefundenen
* Dateien in einer geeigneten Datenstruktur ab.
* Gibt nach dem Einlesen der Filenamen eine Meldung �ber die Zahl der gefundenen
* Text-Dateien aus.</p>
* @author Fabian Steeg
*/
/////////////////////////////////////////////////////////////////////////////////////////////

class Crawler implements CrawlerInterface{
   
    private File startVerzeichnis;
    
    private String[] aktuellesVerz;
    
    private Vector sammelPfade = new Vector(20,5);
    /*   Der Vector zum Sammeln der Pfade...   */
    
    private String[] pfade;
    /*   ...wird am ende auf ein array passender groesse kopiert   */
    
    private boolean gemacht;
    /*   flag-variable zur Ueberpruefung, ob die Pfade bereits geholt wurden   */ 
    
    /////////////////////////////////////////////////////////////
    /**
    * Initialisierungsfunktion
    * �bergibt das Startverzeichnis f�r die Suche nach Dokumenten.
    * @param path der Pfad zum zu indizierenden Verzeichnis
    * 
    */
    /////////////////////////////////////////////////////////////
    
    public void initialize (String path) throws FileNotFoundException{
        this.startVerzeichnis = new File(path);
        Settings.user.talk.message("Suche in \""+this.startVerzeichnis.getAbsolutePath()+"\"");
    }
    //////////////////////////////////////////////////////////////////
    /**
    * Gibt ein String Array zurueck, das die kompletten Pfade zu allen
    * Text- und HTML-Dateien enthaelt, die in dem zu scannenden
    * Verzeichnis liegen, ruft eine rekursive Funktion "holePfade" auf
    * @return String[] mit Pfaden
    */
    //////////////////////////////////////////////////////////////////
    
    public String[] getFiles(){
        
        /*   gibt String[] pfade zurueck, Rekursion nicht hier sondern
        in der aufzurufenden holePfade(file)   */
        
        if(gemacht) return pfade;
        
        //   wenn gemacht == true, wurde die holePfade bereits ausgefuehrt, 
        //   und damit alle Verzeichniss durchsucht.
        
        if (!startVerzeichnis.isDirectory()){
            Settings.user.talk.error("Kein Verzeichnis ausgewaehlt!");        
        }
        
        holePfade(startVerzeichnis);
        
        //   fuer die for-schleife zum Bestuecken 
        //   des arrays aus dem vector:
        
        int f = sammelPfade.size();
        pfade = new String[f];
        for(int i = 0;i<f;i++){
            pfade[i] = sammelPfade.elementAt(i).toString();
        }
        String dateiArten;//   speicher die beruecksichtigten Dateiarten
        if(Settings.user.leseText && Settings.user.leseHypertext)
            dateiArten = "(.txt, .html, .htm)";
        else if(Settings.user.leseText)
            dateiArten = "(.txt)";
        else if(Settings.user.leseHypertext)
            dateiArten = "(.html, .htm)";
        else //   beides nicht ausgewaehlt
            dateiArten = "- da keine Dateitypen ausgewaehlt -";
            
        Settings.user.talk.message("");
        Settings.user.talk.message(f+" lesbare Dateien "+dateiArten+" gefunden!");
        Settings.user.talk.message("");
        
        return pfade;
    }
    
    ///////////////////////////////////////////////////////////////////
    /** 
    *
    * <p> Beschreibung: rekursive Funktion zum Ermitteln der Pfade </p>
    * @param datei Startverzeichnis, ein File
    */  
    ///////////////////////////////////////////////////////////////////
    
    private void holePfade(File datei){
        
        gemacht = true;
        
        aktuellesVerz = datei.list();
        
        //   erzeugung eines arrays mit den 
        //   pfaden des aktuellen verzeichnisses
        
        //   zur Ermittlung der Dateiendung
        String tempString;
        
        //   zum testen, ob ein Pfad eine Datei oder ein Verzeichnis angibt
        File temp; 
        
        /*   Schleife ueber alle Pfade im aktuellen Verzeichnis:   */
        
        int j = aktuellesVerz.length;
        for(int i=0;i<j;i++){
        
            temp = new File(datei  +"/"+ aktuellesVerz[i]);
        
            if(temp.isDirectory()){
                holePfade(temp); //   rekursiver aufruf
                aktuellesVerz = datei.list();
                
                //   anschliessend wieder ins uebergeordnete Verzeichnis wechseln,
                //   dh. aktuellesVerz wieder mit der aktuellen datei.list() bestuecken.
                
            }
            else { //   d.h. ist kein Verzeichnis

                tempString = aktuellesVerz[i].substring(aktuellesVerz[i].length() - 4).toUpperCase();
                //   Teilstring bilden zur Ermittlung der Endung
                if(Settings.user.leseText){
                    if (tempString.compareTo(".TXT")==0){
                        //   bei Erfolg in den Sammel-Vector 
                        sammelPfade.add(datei.getAbsolutePath()+"\\"+ aktuellesVerz[i]); 
                    }
                }
                if(Settings.user.leseHypertext){
                    if (tempString.compareTo(".HTM")==0 || tempString.compareTo("HTML")==0){
                        //   bei Erfolg in den Sammel-Vector 
                        sammelPfade.add(datei.getAbsolutePath()+"\\"+ aktuellesVerz[i]); 
                    }
                }
            }
        }
    }
}