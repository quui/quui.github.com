package searchDesign;

import java.util.*;

///////////////////////////////////////////////////////////////////////    
/**
* Beschreibung:DocumentData implementiert das DocumentDataInterface 
* und ist eine Erweiterung der abstrakten Klasse Data
* Ein DocumentData ist in einer Direktzugriffsstruktur in einem KeyData 
* enthalten. Es speichert eine Document-ID und die Fundstellen des Keys 
* als zwei parallel verwaltete Arrays, positionen und abstaende.</p>
* @author Fabian Steeg
*/
////////////////////////////////////////////////////////////////////////

public class DocumentData extends Data implements DocumentDataInterface {
    
    private int startWertFuerArrays = 5; // erg. kommentar hierzu
    
    private int documentID;
    private int[] positionen = new int[startWertFuerArrays];
    private short[] abstaende = new short[startWertFuerArrays];
    
    //   fuers ranking, DocumentData werden auch zur Speicherung der Erg. benutzt:
    private double bewertung;
    
    public void setRank(double rank){
        this.bewertung = rank;
    }
    public float getRank(){
        return (float) bewertung;
    }
    
    /////////////////////////////////////////////////////////////////////
    /*
    * Funktion, durch die ein DocumentData initialisiert wird.
    *
    * @param docID
    * vom Parser verwaltete ID des aktuellen Dokuments, die auch in der
    * docmap-Datei gespeichert wird
    *
    * @param position
    * Byte-Position des ersten Buchstaben des Schl�sselwortes im Text
    *
    * @param space
    * Anzahl der Nichtwortzeichen (inkl. HTML-Tags) zwischen Schl�sselwort
    * und dem vorigen Wort (unabh�ngig davon, ob letzteres ein Stopwort
    * ist oder nicht) im Text
    */
    //////////////////////////////////////////////////////////////////////

    public void initialize (int documentID, int position, short space){
        
        this.documentID = documentID;
        this.positionen[0] = position;
        this.abstaende[0] = space;
     
    }
    
    ///////////////////////////////////////////////////////////////////
    /*
    * getKey() 
    * @return key - der Schl�ssel des Objektes, hier ein Integer Objekt
    */
    ///////////////////////////////////////////////////////////////////

    public Object getKey(){
        return new Integer(this.documentID);
    }
    
    ///////////////////////////////////////////////////////////////////
    /*
    * Vergleichsfunktion, die einen Schl�ssel "other" erwartet,
    * und durch den R�ckgabewert anzeigt, ob dieser kleiner (<0), 
    * gr��er (>0) oder gleich(==0) dem gespeicherten Schl�ssel ist.
    *
    * @param other Der Schl�ssel, mit dem verglichen wird, hier Integer.
    * @return das Ergebnis des Vergleichs, elem. int.
    */
    ///////////////////////////////////////////////////////////////////
    
    public int compareTo(Object other){
        Integer temp = new Integer(this.documentID);
        Integer temp2 = (Integer)other;
        return (temp2.intValue() - temp.intValue());
    }
    
    ///////////////////////////////////////////////////////////////////////////    
    /*
    * add wird beim Einf�gen eines Data-Objektes in eine Direktzugriffsstruktur
    * benutzt, wenn in dieser bereits ein Objekt mit gleichem Schl�ssel
    * gespeichert ist. 
    *    
    * @param other das Objekt, das hinzugefuegt werden soll, hier DocumentData
    * daher Akkumulieren in den Arrays
    */
    ///////////////////////////////////////////////////////////////////////////
        
    public void add(Object other){
        DocumentData temp = (DocumentData)other;
            
        int k = this.positionen.length;
        
        //   nextFreePosition - Zeiger
        
        int nFPofThis=0;
        int nFPofOther=0;
            
        /*Prozedur zur Verwaltung der Array-Groesse*/
            
        while(nFPofThis<this.positionen.length && this.positionen[nFPofThis] != 0)
            nFPofThis++; //naechsteFreiePosition suchen
                
        while(nFPofOther<temp.positionen.length && temp.positionen[nFPofOther] != 0)
            nFPofOther++; //naechsteFreiePosition suchen
        
        //   Bei Bedarf Arrays vergroessern
        if(nFPofThis + (nFPofOther-1) >= k){
            int [] neuUndGroesserPos = new int[k+nFPofOther];
            System.arraycopy(this.positionen, 0, neuUndGroesserPos, 0, k);
            this.positionen = neuUndGroesserPos;
            short [] neuUndGroesserAbs = new short[k+nFPofOther];
            System.arraycopy(this.abstaende, 0, neuUndGroesserAbs, 0, k);
            this.abstaende = neuUndGroesserAbs;
        }
            
        System.arraycopy(temp.positionen, 0, this.positionen, nFPofThis, nFPofOther);
        System.arraycopy(temp.abstaende, 0 , this.abstaende, nFPofThis, nFPofOther);
           
    }
    
    ///////////////////////////////////////////////////////////////////////////////
    /*
    * getPositions() gibt ein Array zur�ck, welches die Fundstellen des verwalteten
    * Keys enth�lt. Die L�nge des Arrays entspricht genau der Anzahl der
    * gespeicherten Positionen.
    *
    * @return ein Array mit gespeicherten Positionsangaben
    */
    ////////////////////////////////////////////////////////////////////////////////
    
    public int[] getPositions(){
        int nFPofThis=0;
        while(nFPofThis<this.positionen.length && this.positionen[nFPofThis] != 0)
            nFPofThis++; //naechsteFreiePosition suchen
        int[] ergebnis = new int[nFPofThis];
        System.arraycopy(this.positionen, 0, ergebnis, 0, nFPofThis);
        return ergebnis;
    }
    
    //////////////////////////////////////////////////////////
    /** 
    * gibt ein Array zur�ck, dessen L�nge genau der Anzahl der
    * gespeicherten Spaces entspricht
    * @return ein Array mit gespeicherten Space-Angaben
    */
    //////////////////////////////////////////////////////////

    public short[] getSpaces(){
        int nFPofThis=0;
        while(nFPofThis<this.positionen.length && this.positionen[nFPofThis] != 0)
            nFPofThis++; //naechsteFreiePosition suchen
        short[] ergebnis = new short[nFPofThis];
        System.arraycopy(this.abstaende, 0, ergebnis, 0, nFPofThis);
        return ergebnis;
    }
    ///////////////////////////////////////////////////////
    /**
    *  gibt die Anzahl der gespeicherten Fundstellen zur�ck
    * @return die Anzahl der gespeicherten Fundstellen
    */
    ///////////////////////////////////////////////////////
    
    public int size(){
        return getPositions().length;
    }

}