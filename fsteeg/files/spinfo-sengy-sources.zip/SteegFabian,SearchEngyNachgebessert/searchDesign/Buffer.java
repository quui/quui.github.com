package searchDesign;
import java.io.*;

///////////////////////////////////////////////////////////////////
/** 
*
* <p> Beschreibung: Der Buffer dient zur Aufnahme eines Wortes </p>
* 
*/  
///////////////////////////////////////////////////////////////////

class Buffer {     
   
	private char[] chars;// Der Puffer fuer die Zeichen des Wortes.
    private int len;     // Die belegte Laenge von chars. Die tatsaechliche Laenge
                         // liefert chars.length .
    
    static final int maxLength = 256;  // Die Laenge, mit der das Array
                                       // chars angelegt werden sollte.
    public Buffer() {    
        this.chars = new char[maxLength];
	}
    
    public void append(char ch) {  
        if (len < maxLength) {
            chars[len] = ch;  
            len++;
        }
    }
    
    public void reset(){
        this.len = 0;
    }
    public String toString() {    // In der Basisklasse Object ist toString public,
                                  // mithin mu� toString hier auch public sein. 
    return new String(chars, 0, len);
    }
}
