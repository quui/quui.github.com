package searchDesign;

import java.util.*;

/**
 *
 * <p>Beschreibung: DocumentDataInterface wird von der Klasse DocumentData
 * implementiert, welche eine Spezialisierung der abstrakten Klasse Data ist.
 * Ein DocumentData ist in einer Direktzugriffsstruktur in einem KeyData 
 * enthalten. Es speichert eine Document-ID und die Fundstellen des Keys 
 * als zwei parallel verwaltete Arrays, Positionen und Spaces.</p>
 * @version 1.0
 */

public interface DocumentDataInterface {

  /**
   * Funktion, durch die eine Klasse, die dieses Interface
   * implementiert, initialisiert wird.
   *
   * @param docID
   * vom Parser verwaltete ID des aktuellen Dokuments, die auch in der
   * docmap-Datei gespeichert wird
   *
   * @param position
   * Byte-Position des ersten Buchstaben des Schl�sselwortes im Text
   *
   * @param space
   * Anzahl der Nichtwortzeichen (inkl. HTML-Tags) zwischen Schl�sselwort
   * und dem vorigen Wort (unabh�ngig davon, ob letzteres ein Stopwort
   * ist oder nicht) im Text
   */

  public void initialize (int docID, int position, short space);


  /**
   * getPositions() gibt ein Array zur�ck, welches die Fundstellen des verwalteten
   * Keys enth�lt. Die L�nge des Arrays entspricht genau der Anzahl der
   * gespeicherten Positionen.
   *
   * @return ein Array mit gespeicherten Positionsangaben
   */
  public int[] getPositions();

  /** gibt ein Array zur�ck, dessen L�nge genau der Anzahl der
   * gespeicherten Spaces entspricht
   * @return ein Array mit gespeicherten Space-Angaben
   */

 public short[] getSpaces();

 /**
  *  gibt die Anzahl der gespeicherten Fundstellen zur�ck
  * @return die Anzahl der gespeicherten Fundstellen
  */

 public int size();

}