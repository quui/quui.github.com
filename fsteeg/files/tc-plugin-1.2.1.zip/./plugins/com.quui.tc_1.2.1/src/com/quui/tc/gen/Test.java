package com.quui.tc.gen;

public class Test {
    
    public StringBuffer correctValue;
    public Object assertLine;

}
